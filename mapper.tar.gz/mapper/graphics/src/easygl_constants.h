#include <string.h>

#ifndef EASYGL_CONSTANTS_H
#define EASYGL_CONSTANTS_H

/**
 * Some typical (and non typical...) colours, mostly taken from the X11 colours, and put in an enum,
 * so that you can get some reasonable colours from an index variable or something, and so you
 * don't have to generate your own. NUM_COLOR's value should be the same as the number of colours.
 *
 * If you would like to add you own, add them here, and to predef_colors and ps_colors in graphcis.c
 * Note that general custom colour constants should probably just be const t_color variables.
 */
enum color_types {
    WHITE = 0, BLACK, DARKGREY, LIGHTGREY,
    RED, ORANGE, YELLOW, GREEN, CYAN, BLUE, PURPLE, // standard ranbow colours.
    PINK, LIGHTPINK, DARKGREEN, MAGENTA, // some other colours
    BISQUE, // A weird colour, not unlike the "peach" colour of pencil crayons, but closer to "Blanched Almond" and "Moccasin"
    LIGHTSKYBLUE, // A nice light blue
    THISTLE, // A sort of desaturated purple, the colour of thistle flowers
    PLUM, // much closer to pink than the colour of actual plums, and closer to its flower's colour
    KHAKI, // Wikipedia says "a light shade of yellow-green" , but this one is more yellow, and very light
    CORAL, // A burnt pinkish-orange perhaps?
    TURQUOISE, // turquoise
    MEDIUMPURPLE, // A nice medium purple
    DARKSLATEBLUE, // A deep blue, almost purple
    DARKKHAKI, // darker khaki
    LIGHTMEDIUMBLUE, // A light blue, with nice contrast to white, but distinct from "BLUE" (NON-X11)
    SADDLEBROWN, // The browest brown in X11
    FIREBRICK, // dark red
    LIMEGREEN, // a pleasing slightly dark green
    WHITESMOKE,
    PAPAYAWHIP,
    GAINSBORO,
    SILVER,
    DARKORANGE,
    GOLDENROD,
    IVORY,
    DARKORCHID,
    LIGHTSTEELBLUE,
    DARKGOLDENROD,
    WEBGREEN,
    NUM_COLOR
};


/**
 * Line types for setlinestyle(..)
 */
enum line_types {
    SOLID, DASHED
};


/* 
 * Used to pass information from event_loop when a mouse button is pressed 
 * -- which button was pressed, and was shift and/or control being held
 * down when the button was pressed.
 */
typedef struct {
    bool shift_pressed; /* indicates whether a Shift key was pressed when a mouse button is pressed */
    bool ctrl_pressed; /* indicates whether a Ctrl key was pressed when a mouse button is pressed */
    unsigned int button; /* indicates what button is pressed: left click is 1; right click is 3; */
    /* scroll wheel click is 2; scroll wheel forward rotate is 4; */
    /* scroll wheel backward is 5. */
} t_event_buttonPressed; 

#define SEARCH_BUTTON 6
#define MENU_BUTTON 7
#define NEXT_BUTTON 8
#define SEARCH_RESULT_1 9
#define SEARCH_RESULT_2 10
#define SEARCH_RESULT_3 11
#define SEARCH_RESULT_4 12
#define SEARCH_RESULT_5 13
#define HELP_BUTTON 14
#define SELECT_BUTTON 15
#define SELECT_POI_BUTTON 16

#define ZOOM_LEVEL_0 8.0593e-05 
#define ZOOM_LEVEL_1 2.9012e-05
#define ZOOM_LEVEL_2 1.04438e-05 
#define ZOOM_LEVEL_3 3.75956e-06  
#define ZOOM_LEVEL_4 1.35347e-06  
#define ZOOM_LEVEL_5 4.87242e-07  
#define ZOOM_LEVEL_6 1.75384e-07  
#define ZOOM_LEVEL_7 6.3133e-08 
#define ZOOM_LEVEL_8 2.27259e-08 
#define ZOOM_LEVEL_9 8.18989e-09
#define ZOOM_LEVEL_10 2.94091e-09  
#define ZOOM_LEVEL_11 1.06411e-09
#define ZOOM_LEVEL_12 3.81988e-10 
#define ZOOM_LEVEL_13 1.40119e-10 
#define ZOOM_LEVEL_14 5.07328e-11
#define ZOOM_LEVEL_15 1.85025e-11
#define ZOOM_LEVEL_16 7.02016e-12
#define ZOOM_LEVEL_17 2.72848e-12

#define DIRECTION_UP 0
#define DIRECTION_DOWN 1
#define DIRECTION_RIGHT 2
#define DIRECTION_LEFT 3

static const std::string bikeMenu = "Bicycle lanes";
static const std::string subwayMenu = "Subway lines (Toronto Only)";
static const std::string gasStationMenu = "Gas Stations";
static const std::string CafeMenu = "Cafes";
static const std::string HospMenu = "Hospitals";

static const std::string nextString = "Next";
static const std::string selectString = "Select";

static const std::string directions_title = "DIRECTIONS";

#define MENU_BIKE 1
#define MENU_SUBWAY 2
#define MENU_GASSTATIONS 3
#define MENU_CAFE 4
#define MENU_HOSP 5

static const unsigned partialResultPos[] = {
    60, 90, 120, 150, 180
};

struct directionsStruct {
    std::string text;
    std::string distance;
};

#define POPUP_DEFAULT 0
#define POPUP_NEXT 1
#define POPUP_SELECT 2
#define POPUP_NEXTSELECT 3
#define POPUP_POI_SELECT 4

#endif // EASYGL_CONSTANTS_H

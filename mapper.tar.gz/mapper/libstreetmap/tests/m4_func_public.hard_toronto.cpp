#include <random>
#include <iostream>
#include <unittest++/UnitTest++.h>

#include "StreetsDatabaseAPI.h"
#include "m1.h"
#include "m3.h"
#include "m4.h"
#include "newm4.h"

#include "unit_test_util.h"
#include "courier_verify.h"

using ece297test::relative_error;
using ece297test::courier_path_is_legal;


SUITE(hard_toronto_public) {
    TEST(hard_toronto) {
        std::vector<DeliveryInfo> deliveries;
        std::vector<unsigned> depots;
        std::vector<unsigned> result_path;
        bool is_legal;
        
        deliveries = {DeliveryInfo(108031, 6145), DeliveryInfo(60559, 68385), DeliveryInfo(9586, 44723), DeliveryInfo(20806, 4738), DeliveryInfo(62657, 103362), DeliveryInfo(86324, 95265), DeliveryInfo(74264, 39741), DeliveryInfo(99932, 54939), DeliveryInfo(39444, 45923), DeliveryInfo(54844, 51018), DeliveryInfo(989, 83418), DeliveryInfo(36870, 94398), DeliveryInfo(20433, 26525), DeliveryInfo(32640, 88341), DeliveryInfo(53709, 47068), DeliveryInfo(96318, 20466), DeliveryInfo(103884, 68300), DeliveryInfo(71511, 57406), DeliveryInfo(61012, 36713), DeliveryInfo(9727, 94683), DeliveryInfo(76221, 22727), DeliveryInfo(24362, 5404), DeliveryInfo(83735, 21261), DeliveryInfo(26541, 13982), DeliveryInfo(2719, 7906), DeliveryInfo(60037, 44689), DeliveryInfo(98765, 82273), DeliveryInfo(44690, 93630), DeliveryInfo(51692, 46690), DeliveryInfo(83186, 66262), DeliveryInfo(64614, 108770), DeliveryInfo(74490, 89383), DeliveryInfo(79849, 2266), DeliveryInfo(24366, 50531), DeliveryInfo(60773, 74323), DeliveryInfo(79978, 74333), DeliveryInfo(87051, 55738), DeliveryInfo(58034, 16936), DeliveryInfo(80415, 69739), DeliveryInfo(107067, 41567), DeliveryInfo(98564, 99530), DeliveryInfo(98805, 30252), DeliveryInfo(86395, 105662), DeliveryInfo(70831, 36280), DeliveryInfo(27827, 97964), DeliveryInfo(16454, 2725), DeliveryInfo(57705, 39219), DeliveryInfo(7572, 13838), DeliveryInfo(108448, 56452), DeliveryInfo(37191, 98608), DeliveryInfo(57286, 77791), DeliveryInfo(49350, 41462), DeliveryInfo(87576, 21235), DeliveryInfo(92611, 9007), DeliveryInfo(16103, 53986), DeliveryInfo(81784, 11113), DeliveryInfo(68915, 44826), DeliveryInfo(41357, 36493), DeliveryInfo(28917, 85643), DeliveryInfo(102853, 75119), DeliveryInfo(103834, 107566), DeliveryInfo(69352, 91850), DeliveryInfo(86580, 96376), DeliveryInfo(93336, 96967), DeliveryInfo(4863, 6566), DeliveryInfo(14679, 32310), DeliveryInfo(75459, 51728), DeliveryInfo(48014, 77817), DeliveryInfo(96722, 23835), DeliveryInfo(74175, 106669), DeliveryInfo(67807, 74292), DeliveryInfo(67216, 47770), DeliveryInfo(53109, 61805), DeliveryInfo(41171, 99880), DeliveryInfo(46806, 4562), DeliveryInfo(43567, 67285), DeliveryInfo(43215, 77756), DeliveryInfo(51610, 23822), DeliveryInfo(44546, 18710), DeliveryInfo(38892, 39136), DeliveryInfo(50331, 22340), DeliveryInfo(15804, 49666), DeliveryInfo(7650, 47704), DeliveryInfo(68616, 75607), DeliveryInfo(85195, 47378), DeliveryInfo(3909, 33352), DeliveryInfo(28282, 55406), DeliveryInfo(84125, 97481), DeliveryInfo(61155, 75263), DeliveryInfo(47448, 98287), DeliveryInfo(58489, 78564), DeliveryInfo(105649, 97894), DeliveryInfo(107584, 107059), DeliveryInfo(51371, 27010), DeliveryInfo(60356, 25809), DeliveryInfo(40558, 82828), DeliveryInfo(49782, 18735), DeliveryInfo(81702, 1224), DeliveryInfo(65021, 76398), DeliveryInfo(5132, 84210)};
        depots = {14, 55539, 66199, 38064, 87930, 15037, 9781, 42243, 62859, 50192};
        {
        	ECE297_TIME_CONSTRAINT(30000);
        	
        	result_path = traveling_courier(deliveries, depots);
        }
        
        is_legal = courier_path_is_legal(deliveries, depots, result_path);
        CHECK(is_legal);
        
        if(is_legal) {
        	double path_cost = compute_path_travel_time(result_path);
        	std::cout << "QoR hard_toronto: " << path_cost << std::endl;
        } else {
        	std::cout << "QoR hard_toronto: INVALID" << std::endl;
        }
        
    } //hard_toronto

    TEST(hard_multi_toronto) {
        std::vector<DeliveryInfo> deliveries;
        std::vector<unsigned> depots;
        std::vector<unsigned> result_path;
        bool is_legal;
                
        deliveries = {DeliveryInfo(38727, 59698), DeliveryInfo(65778, 85395), DeliveryInfo(72606, 62090), DeliveryInfo(7827, 86986), DeliveryInfo(39431, 91987), DeliveryInfo(15613, 84303), DeliveryInfo(37441, 72613), DeliveryInfo(10284, 60470), DeliveryInfo(16654, 92145), DeliveryInfo(60276, 3579), DeliveryInfo(50829, 60719), DeliveryInfo(85570, 845), DeliveryInfo(6333, 22876), DeliveryInfo(21428, 79783), DeliveryInfo(16472, 42652), DeliveryInfo(98146, 17150), DeliveryInfo(41982, 8788), DeliveryInfo(68237, 58412), DeliveryInfo(29599, 48254), DeliveryInfo(19070, 28138), DeliveryInfo(5781, 41378), DeliveryInfo(105114, 45952), DeliveryInfo(35687, 25254), DeliveryInfo(85570, 7169), DeliveryInfo(98247, 87639), DeliveryInfo(77271, 52297), DeliveryInfo(34495, 71063), DeliveryInfo(102996, 92999), DeliveryInfo(100448, 85395), DeliveryInfo(14852, 10598), DeliveryInfo(643, 74177), DeliveryInfo(58079, 38910), DeliveryInfo(84320, 96524), DeliveryInfo(37873, 73515), DeliveryInfo(85570, 61062), DeliveryInfo(35687, 37695), DeliveryInfo(83605, 92332), DeliveryInfo(48625, 18518), DeliveryInfo(44624, 70990), DeliveryInfo(85570, 96451), DeliveryInfo(17177, 32292), DeliveryInfo(5877, 32281), DeliveryInfo(28423, 102803), DeliveryInfo(97252, 7666), DeliveryInfo(57531, 15850), DeliveryInfo(86538, 45936), DeliveryInfo(54607, 82043), DeliveryInfo(79302, 23466), DeliveryInfo(17330, 13563), DeliveryInfo(20735, 77097), DeliveryInfo(71347, 57609), DeliveryInfo(62158, 58144), DeliveryInfo(99551, 101225), DeliveryInfo(64507, 25401), DeliveryInfo(21654, 70065), DeliveryInfo(30106, 26063), DeliveryInfo(50355, 27368), DeliveryInfo(101852, 92510), DeliveryInfo(71181, 31512), DeliveryInfo(26265, 80945), DeliveryInfo(37340, 81774), DeliveryInfo(96847, 15852), DeliveryInfo(61533, 29574), DeliveryInfo(6131, 70742), DeliveryInfo(9087, 61034), DeliveryInfo(77134, 15234), DeliveryInfo(63984, 85395), DeliveryInfo(8230, 42), DeliveryInfo(106939, 42206), DeliveryInfo(22271, 95320), DeliveryInfo(24130, 24326), DeliveryInfo(32474, 42831), DeliveryInfo(2810, 94984), DeliveryInfo(29327, 46365), DeliveryInfo(79547, 85395), DeliveryInfo(91479, 7528), DeliveryInfo(28999, 97021), DeliveryInfo(85466, 482), DeliveryInfo(90236, 32465), DeliveryInfo(8677, 50387), DeliveryInfo(35687, 35819), DeliveryInfo(73100, 67706), DeliveryInfo(15986, 48494), DeliveryInfo(89699, 94252), DeliveryInfo(4289, 95320), DeliveryInfo(16052, 33731), DeliveryInfo(36581, 66778), DeliveryInfo(33827, 28353), DeliveryInfo(63355, 5926), DeliveryInfo(98196, 60346), DeliveryInfo(10063, 67706), DeliveryInfo(35687, 73875), DeliveryInfo(78247, 52844), DeliveryInfo(88166, 95320), DeliveryInfo(12403, 103519), DeliveryInfo(83417, 95584), DeliveryInfo(35687, 20788), DeliveryInfo(96220, 5528), DeliveryInfo(57602, 100089), DeliveryInfo(32275, 90786)};
        depots = {17, 64796, 22802};
        {
        	ECE297_TIME_CONSTRAINT(30000);
        	
        	result_path = traveling_courier(deliveries, depots);
        }
        
        is_legal = courier_path_is_legal(deliveries, depots, result_path);
        CHECK(is_legal);
        
        if(is_legal) {
        	double path_cost = compute_path_travel_time(result_path);
        	std::cout << "QoR hard_multi_toronto: " << path_cost << std::endl;
        } else {
        	std::cout << "QoR hard_multi_toronto: INVALID" << std::endl;
        }
        
    } //hard_multi_toronto

} //hard_toronto_public


#pragma once
#include <string>
#include "StreetsDatabaseAPI.h"
#include "m1.h"
#include "m3.h"
#include "m4.h"
#include "StreetsDatabase.h"
#include "OSMDatabaseAPI.h"
#include <thread>
#include <chrono>
#include "graphics.h"
#include <cfloat>
#include <iostream>
#include <vector>
#include "constants.h"
#include "LoadOSMData.h"
#include "LatLon.h"
#include "math.h"
#include <boost/algorithm/string.hpp> 

extern std::vector<std::string> mapNames;


// Draws the map. You can assume your load_map (string map_name)
// function is called before this function in the unit tests.
// Your main () program should do the same.
void draw_map();

inline void delay (long milliseconds) {
	std::chrono::milliseconds duration(milliseconds);
	std::this_thread::sleep_for(duration);
}

void drawscreen (void);

void act_on_keypress(char keyPressed, int ketsym);
void act_on_mousebutton (float x, float y, t_event_buttonPressed button_info);

void loadSearchResults();

void drawStreetNamesAndArrows();

void drawStreetSegmentNames(unsigned);

void drawHighlightedStreetSegment(unsigned);
void drawHighlightedStreet(unsigned);

void drawWaterBodies ();
void drawIslands();
void drawGreenery();
void drawHospitals();     
void drawPolygon(unsigned featurePoints, unsigned featureId);
void drawPolygon(std::vector<LatLon> points);

void loadSearchResults();

void drawStartup();

void loadMapData();

std::vector<unsigned> drawPoifromname(string poiname);

void drawHighlightedIntersectionAndPOI(LatLon position);

void drawPointofInterest();

void drawcircle(t_point);

t_point getAbsoluteXYPos(LatLon position);

bool displayIntersectionInfo(float x, float y);

void drawBuildingsAndUnknown();

void zoomWorldBounds(std::vector<unsigned> searchStreetSegmentsIDS);

bool searchCities();

void drawOSMBuildings();

void drawAirportRunway();
void drawTorontoSubways();

void drawStreetSegmentArrows(unsigned i);
void drawGasStations();
void drawCafes();

void drawPaths(double lineWidth, int COLOUR, std::vector<std::vector<LatLon>> vec);

void drawNextSearchResult();

void clearAllVectors();

void handleCallbacks();

void findPathBetweenIntersections();

void findPathBetweenIntersectionPOI();
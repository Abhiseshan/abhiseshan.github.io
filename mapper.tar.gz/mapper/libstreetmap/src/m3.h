#pragma once
#include <vector>
#include <string>
#include <thread>
#include <chrono>
#include <mutex>
#include <iostream>
#include "m1.h"
#include "m2.h"
#include <algorithm>
#include <map>
#include <queue>
#include <climits>
#include <math.h>
#include <sstream>
#define INV_EDGE -1
struct intersection {
    unsigned id;
    int weight;
};
#include <boost/heap/fibonacci_heap.hpp>
#include <boost/heap/binomial_heap.hpp>
#include <boost/heap/d_ary_heap.hpp>
#include <boost/heap/pairing_heap.hpp>
#include <boost/heap/priority_queue.hpp>
#include <boost/heap/skew_heap.hpp> 
#include <boost/heap/heap_concepts.hpp> 
struct info_node
{
    unsigned ID;
    int edgeID; 
    double pathLen;  //travel time
    double cost;
    info_node(unsigned id, int edge_id, double path_len, double c)
    {
        ID= id;
        edgeID=edge_id;
        pathLen=path_len;
        cost= c;             
    }
};
bool operation( info_node a , info_node b);
int dalgo( unsigned source,vector<unsigned> dest );
//define a priority queue with a custom compare function
struct prioritize{
    bool operator ()(const std::pair<unsigned, double>&p1 ,const std::pair<unsigned, double>&p2) const {
        return p1.second > p2.second;
    }
};

struct intersectionStruct {
    double weights;
    std::vector<unsigned> path;
    bool visited;  
};

extern std::vector<std::string> partialSearchResult;

// Returns a path (route) between the start intersection and the end 
// intersection, if one exists. If no path exists, this routine returns 
// an empty (size == 0) vector. If more than one path exists, the path 
// with the shortest travel time is returned. The path is returned as a vector 
// of street segment ids; traversing these street segments, in the given order,
// would take one from the start to the end intersection.
std::vector<unsigned> find_path_between_intersections(unsigned intersect_id_start, unsigned intersect_id_end);


// Returns the time required to travel along the path specified. The path
// is passed in as a vector of street segment ids, and this function can 
// assume the vector either forms a legal path or has size == 0.
// The travel time is the sum of the length/speed-limit of each street 
// segment, plus 15 seconds per turn implied by the path. A turn occurs
// when two consecutive street segments have different street names.
double compute_path_travel_time(const std::vector<unsigned>& path);


// Returns the shortest travel time path (vector of street segments) from 
// the start intersection to a point of interest with the specified name.
// If no such path exists, returns an empty (size == 0) vector.
std::vector<unsigned> find_path_to_point_of_interest (unsigned intersect_id_start, std::string point_of_interest_name);


std::vector<std::string> findPartialSearchResults(std::string partialString);

bool areThreadsRunning();

std::vector<directionsStruct> travelDirections (std::vector<unsigned>segmentIDs);
/*  Found on stack overflow.
 *  Written by Jerry Jeremiah and modified by Abhinav
 *  http://stackoverflow.com/questions/22077802/simple-c-example-of-doing-an-http-post-and-consuming-the-response
 */

#include <stdio.h> /* printf, sprintf */
#include <stdlib.h> /* exit */
#include <unistd.h> /* read, write, close */
#include <string.h> /* memcpy, memset */
#include <sys/socket.h> /* socket, connect */
#include <netinet/in.h> /* struct sockaddr_in, struct sockaddr */
#include <netdb.h> /* struct hostent, gethostbyname */
#include "constants.h"
#include "LatLon.h"
#include <string>
#include "jsonxx.h"        /*JSON Parsing Library */
#include <cassert>
#include <sstream>
#include <fstream>
#include <boost/algorithm/string.hpp>


using namespace std;
using namespace jsonxx;
//Setting to -273 because it is the lowest temperature in Kelvein
static double num = -273.15;
double temperatureData;
bool weatherDataReady = false;

inline void error(const char *msg) { perror(msg); }

void loadWeather(LatLon coordinates)
{    
    weatherDataReady = false;
    /* first what are we going to send and where are we going to send it? */
    int portno = 80;
    const char *host = "api.openweathermap.org";
    
    std::string request = "GET /data/2.5/weather?lat=" + std::to_string(coordinates.lat) + "&lon=" +
                            std::to_string(coordinates.lon) + "&appid=" + apiID + " HTTP/1.0\r\n\r\n"; 

    const char *message = request.c_str();
    
    struct hostent *server;
    struct sockaddr_in serv_addr;
    int sockfd, bytes, sent, received, total;
    char response[8056];

    /* create the socket */
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0){ 
        error("ERROR opening socket");
        return;
    }

    /* lookup the ip address */
    server = gethostbyname(host);
    if (server == NULL){ 
        error("ERROR, no such host");
        return;
    }

    /* fill in the structure */
    memset(&serv_addr,0,sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(portno);
    memcpy(&serv_addr.sin_addr.s_addr,server->h_addr,server->h_length);

    /* connect the socket */
    if (connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr)) < 0){
        error("ERROR connecting");
        return;
    }

    /* send the request */
    total = strlen(message);
    sent = 0;
    do {
        bytes = write(sockfd,message+sent,total-sent);
        if (bytes < 0){
            error("ERROR writing message to socket");
            return;
        }
        if (bytes == 0)
            break;
        sent+=bytes;
    } while (sent < total);

    /* receive the response */
    memset(response,0,sizeof(response));
    total = sizeof(response)-1;
    received = 0;
    do {
        bytes = read(sockfd,response+received,total-received);
        if (bytes < 0) {
            error("ERROR reading response from socket");
            return;
        }
        if (bytes == 0)
            break;
        received+=bytes;
    } while (received < total);

    if (received == total) {
        error("ERROR storing complete response from socket");
        return;
    }

    /* close the socket */
    close(sockfd);

    //Removing the HTTP header
    std::string resp = string(response);
    size_t pos = resp.find("\r\n\r\n");
    std::string jsonString = resp.substr(pos+4);
            
    //JSON Parsing
    Object o;
    if (o.parse(jsonString)){
        if (o.get<Object>("main").has<Number>("temp")){
            num = o.get<Object>("main").get<Number>("temp");
            num -= 273.15; //Convert from celcius to kelvin
        }
    }

    weatherDataReady = true;
    temperatureData = num;
}
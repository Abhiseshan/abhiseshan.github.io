/*
 * LoadOSMData handles loading data from Layer1 API. This file contains the definitions for all global
 * variables and functions shared between the files.
 */

#pragma once

#include <string.h>
#include "OSMDatabaseAPI.h"
#include "m1.h"
#include "m2.h"
#include <vector>
#include "constants.h"
#include <thread>
#include <chrono>
#include <mutex>

extern bool isOSMDoneLoading;

extern std::vector<std::vector<LatLon>> HWMotorways;
extern std::vector<std::vector<LatLon>> HWTrunk;
extern std::vector<std::vector<LatLon>> HWPrimary;
extern std::vector<std::vector<LatLon>> HWSecondary;
extern std::vector<std::vector<LatLon>> HWTertiary;
extern std::vector<std::vector<LatLon>> HWUnclassified ;
extern std::vector<std::vector<LatLon>> HWResidential;
extern std::vector<std::vector<LatLon>> HWService;
extern std::vector<std::vector<LatLon>> HWMotorwaysLink;
extern std::vector<std::vector<LatLon>> HWTrunkLink;
extern std::vector<std::vector<LatLon>> HWPrimaryLink;
extern std::vector<std::vector<LatLon>> HWSecondaryLink;
extern std::vector<std::vector<LatLon>> HWTertiaryLink;
extern std::vector<std::vector<LatLon>> HWPedestrian;
extern std::vector<std::vector<LatLon>> OSMBuildings;
extern std::vector<std::vector<LatLon>> Runways;
extern std::vector<std::vector<LatLon>> Taxiways;
extern std::vector<std::vector<LatLon>> BloorDanforthSubway;
extern std::vector<std::vector<LatLon>> YongeUniversitySpadinaSubway;
extern std::vector<std::vector<LatLon>> ScarboroughLine;
extern std::vector<std::vector<LatLon>> SheppardLine;
extern std::vector<std::vector<LatLon>> Railways;
extern std::vector<std::vector<LatLon>> BicyclePaths;


void loadOSMdatabase(std::string OSMBinLocation);

void destroyOSMdatabase();
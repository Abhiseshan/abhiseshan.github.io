#include "m3.h"

// Vector containing search results for autocomplete
std::vector<std::string> partialSearchResult;
bool isAnIntersection;
bool killThreads;
std::string searchQuerry;

//For Thread safety
std::mutex thread_lock1;
std::mutex thread_lock2;

//Thread manager
std::list<std::thread::id> threadManager;

//Private functions//
void findPartialStreetNames(std::string partialString);
void findPartialStreet2Names(std::string partialString);
void findPartialIntersectionNames(std::string partialString);
void findPartialPOINames(std::string partialString);
bool searchPartialResults(std::string result);

intersectionStruct *intersections;

//#define DEBUG_GRAPHICAL
//#define DEBUG

// Checks for duplicate search results 
bool searchPartialResults(std::string result) {
    for (auto itr = partialSearchResult.begin(); itr != partialSearchResult.end(); itr++){
        if ((*itr).find(result) != std::string::npos)
            return true;
    }
    return false;
}

// Finds search results for autocomplete 
std::vector<std::string> findPartialSearchResults(std::string partialString){
    searchQuerry = partialString;
    //If there are current threads running, it sends the kill signal and polls till the threads are dead
    
    while (!threadManager.empty())
        killThreads = true;
    //Sets the kill thread flag to false to not kill the newly created threads
    killThreads = false;
    
    boost::algorithm::to_lower(partialString); //Converts the search input into lowercase to compare
    partialSearchResult.clear();
    
    if (partialString.find("&") != std::string::npos || partialString.find(",") != std::string::npos)
        isAnIntersection = true;
    else
        isAnIntersection = false;
        
    //Start threads
    std::thread streetThread(findPartialStreetNames, partialString);
    std::thread intersectionsThread(findPartialIntersectionNames, partialString);
    std::thread POIThread(findPartialPOINames, partialString); 
    
    //Process map names to find partial match
    //Checks for result lesser than 5 to make sure there are only 5 matches or it exits.
    for (auto itr = mapNames.begin(); (itr != mapNames.end()) && (partialSearchResult.size() < 5) && !isAnIntersection; itr++){
        //Converting to lower case
        std::string lowerCaseString = *itr;
        boost::algorithm::to_lower(lowerCaseString);
        //Searching for part of the string
        thread_lock1.lock();
        if (lowerCaseString.find(partialString) != std::string::npos) {
            if (partialSearchResult.size() < 5)
                partialSearchResult.push_back((*itr));
        }
        thread_lock1.unlock();
    }
    
    //Waits for other threads to finish
    streetThread.join();
    intersectionsThread.join();
    POIThread.join();

    handleCallbacks();
    return partialSearchResult;
}
// Finds street names containing the string input from the user in the search bar
void findPartialStreetNames(std::string partialString){
    //Add the thread into the thread manager
    threadManager.push_back(std::this_thread::get_id());
    for (auto itr = streetNames.begin(); (itr != streetNames.end()) && (partialSearchResult.size() < 5) && !isAnIntersection; itr++){
        if (killThreads){
            thread_lock2.lock();
            threadManager.remove(std::this_thread::get_id());
            thread_lock2.unlock();
            return;
        }
        //Converting to lower case
        std::string lowerCaseString = *itr;
        boost::algorithm::to_lower(lowerCaseString);
        //Searching for part of the string
        thread_lock1.lock();
        if (lowerCaseString.find(partialString) != std::string::npos) {
            if (!searchPartialResults(*itr)) {
                if (partialSearchResult.size() < 5)
                    partialSearchResult.push_back((*itr));
            }
        }
        thread_lock1.unlock();
    }
    thread_lock2.lock();
    //Remove the thread once it has completed from the thread manager
    threadManager.remove(std::this_thread::get_id());
    thread_lock2.unlock();
}

/* Had to make a new function since this one runs on the current thread while the other runs on a new thread
 * Also this does not check if it is an intersection or not */
void findPartialStreet2Names(std::string partialString){
    for (auto itr = streetNames.begin(); (itr != streetNames.end()) && (partialSearchResult.size() < 5); itr++){
        if (killThreads)
            return;
        //Converting to lower case
        std::string lowerCaseString = *itr;
        boost::algorithm::to_lower(lowerCaseString);
        //Searching for part of the string
        if (lowerCaseString.find(partialString) != std::string::npos) {
            if (!searchPartialResults(*itr))
                partialSearchResult.push_back((*itr));
        }
    }
}
// Finds POI names containing the string input from the user in the search bar
void findPartialPOINames(std::string partialString){
    threadManager.push_back(std::this_thread::get_id());
    for (auto itr = POINames.begin(); (itr != POINames.end()) && (partialSearchResult.size() < 5) && !isAnIntersection; itr++){
        if (killThreads){
            thread_lock2.lock();
            threadManager.remove(std::this_thread::get_id());
            thread_lock2.unlock();
            return;
        }
        //Converting to lower case
        std::string lowerCaseString = *itr;
        boost::algorithm::to_lower(lowerCaseString);
        //Searching for part of the string
        thread_lock1.lock();
        if (lowerCaseString.find(partialString) != std::string::npos) {
            if (!searchPartialResults(*itr)) {
                if (partialSearchResult.size() < 5)
                    partialSearchResult.push_back((*itr));
            }
        }
        thread_lock1.unlock();
    }
    thread_lock2.lock();
    threadManager.remove(std::this_thread::get_id());
    thread_lock2.unlock();
}


void findPartialIntersectionNames(std::string partialString){
    threadManager.push_back(std::this_thread::get_id());
    //Assuming street 1 is valid
    if (isAnIntersection){
        if (killThreads){
            thread_lock2.lock();
            threadManager.remove(std::this_thread::get_id());
            thread_lock2.unlock();
            return;
        }
        partialSearchResult.clear(); //Making sure results are empty
        std::string street1;
        std::string street2;

        std::size_t pos = partialString.find(',');
        std::size_t pos1 = partialString.find("&");

        if (pos < (partialString.length()-1) || pos1 < (partialString.length()-1)){
            if (pos !=std::string::npos && pos1 == std::string::npos){
                street1 = searchQuerry.substr(0,pos); //Extracts the first street name
                if (partialString[pos+1] == ' ') // Detects if the format entered in is "street1, street2" 
                    pos+=1;
                street2 = partialString.substr(pos+1); // Extracts second street name
            } else if(pos1 != std::string:: npos && pos == std::string::npos){
                street1 = searchQuerry.substr(0,pos1-1); //Extracts the first street name
                street2 = partialString.substr(pos1+2); // Extracts second street name
            }

            std::vector<std::string> tempResult;

            //Getting the results for the second street name
            findPartialStreet2Names(street2);
            for (auto itr = partialSearchResult.begin(); itr != partialSearchResult.end(); itr++){
                tempResult.push_back(street1 + " & " + *itr);
            }
            //Clearing results from partial name match anding the intersection name match to it.
            partialSearchResult.clear();
            partialSearchResult.insert(partialSearchResult.begin(), tempResult.begin(), tempResult.end());
        }
    }
    thread_lock2.lock();
    threadManager.remove(std::this_thread::get_id());
    thread_lock2.unlock();
}

bool areThreadsRunning(){
    return !threadManager.empty();
}

std::vector<unsigned> find_path_between_intersections(unsigned intersect_id_start, unsigned intersect_id_end) {
    std::size_t size = getNumberOfIntersections();  
    
    intersections = new intersectionStruct[size];
        
    //If the intersections are the same
    if (intersect_id_start == intersect_id_end){
        std::vector<unsigned> temp;
        return temp;
    }
    
    //Set weights to infinity and visited to false for all elements
    for (unsigned z=0; z < size; z++){
        intersections[z].weights = DBL_MAX;
        intersections[z].visited = false;
    }
        
    /*
     * Test table: For future reference in case anyone wants to implement a different heap
     * Std::Priority Queue: 7.11
     * Fibonacchi Heap: 8.50
     * Binomial Heap: 9.20
     * D_ary_heap: Did not compile
     * Paring Heap: 8.24
     * Priority Queue: 7.16
     * Skew Heap: 7.65
     */
    
    //Priority queue to store intersectionID, weight pairs
    std::priority_queue<std::pair<unsigned,double> ,std::vector<std::pair<unsigned,double>>, prioritize> heap; 

    //Pushing the source with weight 0
    heap.push(std::make_pair(intersect_id_start, intersections[intersect_id_start].weights = 0));
    
    bool found = false;
    
    while (!found && heap.size() != 0){
        pair<unsigned, double> currentNode = heap.top();
        heap.pop();
                
        unsigned currentID = currentNode.first;
        
        if (currentID == intersect_id_end) {
            found = true;
            break;
        }
        
        //Check if current node has already been visited
        if (intersections[currentID].visited)
            continue;
        
        intersections[currentID].visited = true; //If not, set it true since we are visiting the node now
        
        //Gives us all the valid adjacent Nodes after checking for one ways
        std::vector<unsigned> adjNodes = find_adjacent_intersections(currentID);
        
        for (auto itr = adjNodes.begin(); itr != adjNodes.end() && !found; itr++){
            vector<unsigned> streetSegmentsID;
            
            //Checking for the street segments between the current intersection and the intersection
            //we are looking at
            if (!intersections[*itr].visited){
                std::vector<unsigned> streetSegments = find_intersection_street_segments(currentID);
                                
                for (auto itr2 = streetSegments.begin(); itr2 != streetSegments.end(); itr2++){
                    StreetSegmentInfo sgi = getStreetSegmentInfo(*itr2);
                    if (sgi.from == currentID && sgi.to == *itr)
                        streetSegmentsID.push_back(*itr2);
                    else if (sgi.to == currentID && sgi.from == *itr && !sgi.oneWay)
                        streetSegmentsID.push_back(*itr2);
                }

                for (auto itr3 = streetSegmentsID.begin(); itr3 != streetSegmentsID.end(); itr3++){
                    unsigned streetSegment = *itr3;
                    
#ifdef DEBUG_GRAPHICAL
                    setcolor(YELLOW);
                    drawHighlightedIntersectionAndPOI(getIntersectionPosition(intersect_id_start));
                    drawHighlightedIntersectionAndPOI(getIntersectionPosition(intersect_id_end));

                    setcolor(RED);
                    drawHighlightedStreetSegment(streetSegment);
                    flushinput();
#endif //Debug
                    
                    /*
                     * Dijkstra's Algorithm Implementation
                     * double travelTime = compute_path_travel_time(tempPath); 
                     * Basically travel time pure is just dijkstras and travel time has A*7
                     */
                    

                    double travelTime = intersections[currentID].weights + findStreetSegmentTravelTime(streetSegment);
                    double travelTimePure = travelTime;  
                    travelTime *= HEURISTIC_WEIGHT;
                    travelTime += find_distance_between_two_points(getIntersectionPosition(*itr), getIntersectionPosition(intersect_id_end))/1000;

                    //If street ids are different, a turn is dectected
                    if (!intersections[currentID].path.empty()) {
                        if (streetSegmentStreetID[intersections[currentID].path.back()] != streetSegmentStreetID[streetSegment]){
                            travelTime += HEURISTIC_TURN_TIME;
                            travelTimePure += TURN_TIME;
                        }
                    }
                    

#ifdef DEBUG
                    std::cout<<"Travel Time: "<<travelTime<<std::endl;
                    std::cout<<"stt :"<< findStreetSegmentTravelTime(streetSegment)<<std::endl;
                    std::cout<<"Weights: "<<intersections[currentID].weights<<std::endl;
                    std::cout<<"heuristics :"<<heuristics<<std::endl;
                    std::cout<<"distance :"<<find_distance_between_two_points(getIntersectionPosition(*itr), getIntersectionPosition(intersect_id_end))/1000<<std::endl;
                    std::cout<<"travel Time :"<<travelTime<<std::endl;
#endif //Debug
                    
                    //Id travel time to a node is lesser, it then replaces it in the weights
                    if (intersections[*itr].weights > travelTimePure){
#ifdef DEBUG
                        if (intersections[*itr].weights != DBL_MAX) {
                            std::cout<<"Override: "<<*itr<<std::endl;
                        }
                        std::cout<<"Current ID: "<<currentID<<std::endl;
                        std::cout<<"Weights: "<<intersections[*itr].weights<<std::endl;
                        std::cout<<"travel Time: "<<travelTime<<std::endl;
                        std::cout<<"Itr: "<<*itr<<std::endl;
#endif //Debug
                        intersections[*itr].weights = travelTimePure;
                        intersections[*itr].path.clear();
                        intersections[*itr].path.insert(intersections[*itr].path.begin(), intersections[currentID].path.begin(),intersections[currentID].path.end());
                        intersections[*itr].path.push_back(streetSegment);
                        heap.push(std::make_pair(*itr, travelTime));
                    }
                }
            }
        }
    }
    
    std::vector<unsigned> result(intersections[intersect_id_end].path.begin(), intersections[intersect_id_end].path.end());
    
    delete[] intersections;
    return result;
}


double compute_path_travel_time(const std::vector<unsigned>& path){
    if (path.empty())
        return 0;
    
    unsigned previous = *(path.begin());
    double travelTime = findStreetSegmentTravelTime(previous);
    for (auto itr = path.begin()+1; itr != path.end(); itr++){

        travelTime += findStreetSegmentTravelTime(*itr);

        //Check for 15 second time addition                
        if (streetSegmentStreetID[*itr] != streetSegmentStreetID[previous]){
            travelTime += TURN_TIME;
        }
        
        previous = *itr;
    }
    
    return travelTime;
}
//Finds path from the intersection source to the first poi it meets as specified by the user using dijkstra algorithm
std::vector<unsigned> find_path_to_point_of_interest (unsigned intersect_id_start, std::string point_of_interest_name)
{
    std::vector<unsigned> POIIds=find_closest_pois_from_intersection(intersect_id_start,point_of_interest_name);
    std::vector<unsigned> dest= get_closest_intersection_poiids(POIIds);
    std::size_t size = getNumberOfIntersections();  
    std::vector<unsigned> result2;
    intersections = new intersectionStruct[size];
    
    //Set weights to infinity and visited to false for all elements
    for (unsigned z=0; z < size; z++){
        intersections[z].weights = DBL_MAX;
        intersections[z].visited = false;
    }
    
    std::priority_queue<std::pair<unsigned,double> ,std::vector<std::pair<unsigned,double>>, prioritize> heap; 
    
    //Pushing the source with weight 0
    heap.push(std::make_pair(intersect_id_start, intersections[intersect_id_start].weights = 0));
    bool found = false;
    
    while (!found && heap.size() != 0){
        pair<unsigned, double> currentNode = heap.top();
        heap.pop();
        unsigned currentID = currentNode.first;
        //Checks if it current node is the same as one the poi nodes in the destination vector
        auto it= find(dest.begin(),dest.end(),currentID );
        if (it!=dest.end()) {
            std::vector<unsigned> result(intersections[currentID].path.begin(), intersections[currentID].path.end());
            result2=result;
            found = true;
        }

        //Check if current node has already been visited
        if (intersections[currentID].visited)
            continue;
        intersections[currentID].visited = true; //If not, set it true since we are visiting the node now
        
        //Gives us all the valid adjacent Nodes after checking for one ways
        std::vector<unsigned> adjNodes = find_adjacent_intersections(currentID);
        // Goes through all the adjacent nodes and finds the street segment from the source to the adjacent nodes
        for (auto itr = adjNodes.begin(); itr != adjNodes.end() && !found; itr++){
            vector<unsigned> streetSegmentsID;
            if (!intersections[*itr].visited){
                std::vector<unsigned> streetSegments = find_intersection_street_segments(currentID);
                                
                for (auto itr2 = streetSegments.begin(); itr2 != streetSegments.end(); itr2++){
                    StreetSegmentInfo sgi = getStreetSegmentInfo(*itr2);
                    if (sgi.from == currentID && sgi.to == *itr){
                        streetSegmentsID.push_back(*itr2);
                    }
                    else if (sgi.to == currentID && sgi.from == *itr && !sgi.oneWay) {
                        streetSegmentsID.push_back(*itr2);
                    }                 
                }

                for (auto itr3 = streetSegmentsID.begin(); itr3 != streetSegmentsID.end(); itr3++){
                   
                    unsigned streetSegment = *itr3;
                    /*
                     * Dijkstra's Algorithm Implementation
                     */
                    //Compute Travel time for each street segment
                    double travelTime = intersections[currentID].weights + find_street_segment_travel_time(streetSegment);
                    if (!intersections[currentID].path.empty()) {
                        if (streetSegmentStreetID[intersections[currentID].path.back()] != streetSegmentStreetID[streetSegment]){
                            travelTime += TURN_TIME;
                        }
                    }
                    //update the new weights for adjacent nodes and save the path
                    if (intersections[*itr].weights > travelTime){
                        intersections[*itr].weights = travelTime;
                        intersections[*itr].path.clear();
                        intersections[*itr].path.insert(intersections[*itr].path.begin(), intersections[currentID].path.begin(),intersections[currentID].path.end());
                        intersections[*itr].path.push_back(streetSegment);
                        heap.push(std::make_pair(*itr, travelTime));
                    }
                }
            }
        }
    }
    
    delete[] intersections;
    return  result2;
}

// Function which computes the travel directions for the route
std::vector<directionsStruct> travelDirections (std::vector <unsigned> segmentID){
    
    // Vector to store the text and distance associated with the route. Will be passed in to graphics, to draw it in the side direction bar
    std::vector<directionsStruct> directions; 
    
    // Struct containing the text and distance
    directionsStruct dir;
    
    // Getting the street ID for the first street segment of the route
    auto iter = segmentID.begin();
    StreetSegmentInfo sgiprev = getStreetSegmentInfo(*iter);
    unsigned streetIDprev = sgiprev.streetID;
    
    // Computes the distance (length) travelled in the first segment
    double distance = (find_street_segment_length(*iter))*0.001;
    
    
    // Checks whether the starting street is known or unknown, and prints the direction accordingly
    if (getStreetName(streetIDprev)!= "<unknown>"){
        dir.text= "Head straight on " + getStreetName(streetIDprev) + " for ";
    }
    else{
        dir.text= "Head straight for ";
    }
    
    /* Iterates through all the street segments
     * Checks if there is a turn by comparing the street IDs
     * Prints the turn accordingly
     */
    for (iter = segmentID.begin()+1;iter!= segmentID.end(); iter++){
        StreetSegmentInfo sgicurr = getStreetSegmentInfo(*iter);
        unsigned streetIDcurr = sgicurr.streetID;
        
        // If turn detected
        if (streetIDprev != streetIDcurr){
            
            // Prints the distance that was traveled straight in kms on a street until a turn is detected                       
            double temp = distance;
            
            // Rounds off the distance to one decimal place
            temp = temp * 10;
            temp = (int) temp;
            temp /= 10;
            std::stringstream ss;
            
            // If rounded value is 0, then round to 0.1 km
            if (temp == 0){
                temp = 0.1;
            }
            
            // Sends the distance value to the direction vector
            ss << fixed << setprecision( 1 ) << temp;
            dir.distance = ss.str() + " km";
            directions.push_back(dir);
            
            // Gets the street segment info for the segment right before the segment turned on to
            StreetSegmentInfo sgiprev = getStreetSegmentInfo(*(iter-1));
            unsigned startOfPrevSegment;
            unsigned endOfPrevSegment;
            unsigned endOfNextSegment;
            
            // Checking which node of the two segments (the one before the turn, and the one turned on to) are common
            if (sgiprev.to == sgicurr.from){
                startOfPrevSegment = sgiprev.from;
                endOfPrevSegment = sgiprev.to;
                endOfNextSegment = sgicurr.to;               
            }
            else if (sgiprev.to == sgicurr.to){
                startOfPrevSegment = sgiprev.from;
                endOfPrevSegment = sgiprev.to;
                endOfNextSegment = sgicurr.from; 
            }
            else if (sgiprev.from == sgicurr.to){
                startOfPrevSegment = sgiprev.to;
                endOfPrevSegment = sgiprev.from;
                endOfNextSegment = sgicurr.from; 
            }
            else{
                startOfPrevSegment = sgiprev.to;
                endOfPrevSegment = sgiprev.from;
                endOfNextSegment = sgicurr.to; 
            }
            
            // Getting the xy coordinates of the location of intersection
            t_point startSegmentCoordinates = getAbsoluteXYPos(getIntersectionPosition(startOfPrevSegment));
            
            t_point endSegmentCoordinates = getAbsoluteXYPos(getIntersectionPosition(endOfPrevSegment));
            
            t_point nextSegmentCoordinates = getAbsoluteXYPos(getIntersectionPosition(endOfNextSegment));
            
            
            /* To check whether the turn is made to the left or the right
             * If the segment started from has the starting point A(x,y) and end point B(x,y) and 
             * the end of the segment turned onto is point C(x,y);
             * Then, the determinant formula is used
             * Determinant = (Bx - Ax)*(Cy - Ay) - (By - Ay)*(Cx-Ay)
             * If determinant < 0 -> turn is to the left
             * If determinant > 0 -> turn is to the right
             * If determinant = 0 -> travel straight 
             * Only works for positive coordinates so absolute value of the coordinates is used*/
                        
            float determinant = ((fabs(endSegmentCoordinates.x) - fabs(startSegmentCoordinates.x))*(fabs(nextSegmentCoordinates.y)-fabs(startSegmentCoordinates.y))) - ((fabs(endSegmentCoordinates.y) - fabs(startSegmentCoordinates.y))*(fabs(nextSegmentCoordinates.x)-fabs(startSegmentCoordinates.x))); 
            
            // Left turn
            if (determinant < 0) {
               
                if (getStreetName(streetIDcurr)!= "<unknown>"){
                    std::cout << "Turn left onto " << getStreetName(streetIDcurr)<< endl;
                    dir.text = "Turn left onto " + getStreetName(streetIDcurr);
                    dir.distance = "";
                    directions.push_back(dir);
                }
                else{
                    std::cout << "Turn left" << endl;
                    dir.text = "Turn left";
                    dir.distance = "";
                    directions.push_back(dir);
                }
            }
            // Right turn
            else if (determinant > 0){
                
                if (getStreetName(streetIDcurr)!= "<unknown>"){
                    std::cout << "Turn right onto " << getStreetName(streetIDcurr) << endl;
                    dir.text = "Turn right onto " + getStreetName(streetIDcurr);
                    dir.distance = "";
                    directions.push_back(dir);
                }
                else{
                    std::cout << "Turn right" << endl;
                    dir.text = "Turn right";
                    dir.distance = "";
                    directions.push_back(dir);
                }
            }
            
            // Go straight
            else{
                
                if (getStreetName(streetIDcurr)!= "<unknown>"){
                    dir.text = "Continue onto " + getStreetName(streetIDcurr);
                    dir.distance = "";
                    directions.push_back(dir);
                }
                else{
                    dir.text = "Continue straight";
                    dir.distance = "";
                    directions.push_back(dir);
                }
            }
            dir.text = "Travel straight";
            distance = 0;
            streetIDprev = streetIDcurr;
        }
        // Calculate the distance traveled on one street
        distance += (find_street_segment_length(*iter))*0.001;  
    }
    
    // Send the distance to the direction vector   
    double temp = distance;
    temp = temp * 10;
    temp = (int) temp;
    temp /= 10;
    std::stringstream ss;
    if (temp == 0){
        temp = 0.1;
    }
    ss << fixed << setprecision( 1 ) << temp;
    dir.distance = ss.str() + " km";
    directions.push_back(dir);    
    
    return directions;
}
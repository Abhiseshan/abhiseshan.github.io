#include "StreetsDatabaseAPI.h"
#include "m1.h"
#include "StreetsDatabase.h"
#include "OSMDatabaseAPI.h"
#include "graphics.h"
#include <iostream>
#include <math.h>
#include <cmath>
#include <boost/multiprecision/cpp_dec_float.hpp>
#include <boost/math/special_functions/sin_pi.hpp>
#include "constants.h"
#include "m3.h"

bool isStreetsDoneLoading = false;

std::unordered_map<double,double> cos_table;
//Map for street names and id
std::unordered_multimap<std::string, unsigned> streetNameIDmap;
std::vector<std::string> streetNameSegmentIDmap;

// Vector to store adjacent vectors indexed by intersection id
std::vector<std::vector<unsigned>> adjacentIntersections;
//std::vector<unsigned> 
// Vector containing street segments indexed by the intersection id
std::vector<std::vector<unsigned>> id_with_Streetnames;

//Map containing theta and Rcoordinates
std::unordered_multimap<int, rtdata> rtcoordinates;

//float cosArray[90001]; //An array to store all the cosine values
//std::unordered_map<LatLon, unsigned > Pointofinterest;

// Map containing street IDs mapped to intersection IDs
std::unordered_map<unsigned, std::vector<unsigned>> StreetIDandIntersectionIDmap;

//Vector containing street IDs and street Segments 
std::vector<std::vector<unsigned>> streetIDsandStreetSegments;

//Vectors to speed up all street segment info functions
std::vector<double> streetSegmentTravelTime;
std::vector<double> streetSegmentStreetID;
std::vector<float> streetSegmentSpeedLimit;
std::vector<unsigned> streetSegmentIntersectionFrom;
std::vector<unsigned> streetSegmentIntersectionTo;
std::vector<unsigned> streetSegmentCurvePointCount;
std::vector<double> streetSegmentLength;
//std::vector<std::unordered_map<unsigned, unsigned>> intersectionSegments;

// Vectors containing names. It is here since the m1 thread completes earlier than the OSM thread.
std::vector<std::string> streetNames;
std::vector<std::string> POINames;

// Array containing cosine values from 0 to 90
double cosArray[MAX_COS_VALUES];

//To figure out map bounds
double greatestLattitude, smallestLattitude;
double greatestLongitude, smallestLongitude;
double centerLat, centerLon;

xy intersection0Coordinates, centerCoordinates;

//load the map
bool load_map(std::string map_name) {
    
    long double R = EARTH_RADIUS_IN_METERS / 1000;

    bool load_success = loadStreetsDatabaseBIN(map_name);

    //If the data is successfully loaded from the bin, the formation of new data structures takes place.
    //Otherwise false is returned.

    if (load_success) {
    
        unsigned i = 0, streetnum = getNumberOfStreets(), intersectionNum = getNumberOfIntersections(), segmentNum = getNumberOfStreetSegments(), POINum = getNumberOfPointsOfInterest();
                
        // Array containing the cosine values from 0 to 90 degrees 
        // A precision of 4 decimal places is set
        for (double k = 0; k <= 90; k+=0.001){
            cosArray[(unsigned)(k*1000)] = std::cos(k * DEG_TO_RAD);
        }
        
        // Calculating the center of the map 
        LatLon coordinate0 = getIntersectionPosition(0);
        greatestLattitude = smallestLattitude = coordinate0.lat;
        greatestLongitude = smallestLongitude = coordinate0.lon;
        
        centerLat = (smallestLattitude + greatestLattitude) / 2;
        centerLon = (smallestLongitude + greatestLongitude) / 2;

        intersection0Coordinates.x = R * cos(centerLat * DEG_TO_RAD) * cos(centerLon * DEG_TO_RAD);
        intersection0Coordinates.y = R * cos(centerLat * DEG_TO_RAD) * sin(centerLon * DEG_TO_RAD);        
        
        // Loading of data structures 
        
        // 3. Multimap containing streetIDs mapped to its corresponding street segments
        std::unordered_multimap<unsigned, unsigned> StreetIDandStreetSegments;
                
        for (i = 0; i < segmentNum; i++){
            StreetSegmentInfo sgi = getStreetSegmentInfo(i);
            StreetIDandStreetSegments.insert(std::make_pair(sgi.streetID,i));
            streetNameSegmentIDmap.push_back(getStreetName(sgi.streetID));
            streetSegmentStreetID.push_back(sgi.streetID);
            streetSegmentSpeedLimit.push_back(sgi.speedLimit);
            streetSegmentIntersectionFrom.push_back(sgi.from);
            streetSegmentIntersectionTo.push_back(sgi.to);
            streetSegmentCurvePointCount.push_back(sgi.curvePointCount);
            streetSegmentLength.push_back(find_street_segment_length(i));
            streetSegmentTravelTime.push_back(find_street_segment_travel_time(i));
        }
                
        // 1. Multimap of street names and their corresponding ids
        
        // The street name is the key, and its value is the street id
        // i =  street id
        for (i = 0; i < streetnum; i++) {
            streetNameIDmap.insert(std::make_pair(getStreetName(i), i));
            std::string name = getStreetName(i);
            if (name != "<unknown>" && name.find("Ramp") == std::string::npos 
                    && name.find("ramp") == std::string::npos)
                streetNames.push_back(name);
        }
        
        // Implementation of the following data structures:
        // 1. Vector containing adjacent intersections indexed by intersection id
        // 2. Vector containing street segments indexed by intersection id
        
        // Temporary vector to store adjacent intersections
        std::vector<unsigned> adj;
        
        // Temporary set to of adjacent intersections
        std::set<unsigned> set; 
        
        // Temporary vector containing street segments
        std::vector<unsigned>streetids;
        
        // i = intersection id
        for (i = 0; i < intersectionNum; i++) {
            hash_into_map(i);
            
            // Total number of street segments at the specific intersection
            int total_street_segs = getIntersectionStreetSegmentCount(i);
            for (int j = 0; j < total_street_segs; j++) {
                 
                // Stores the specific street segment id in a vector
                unsigned temp = getIntersectionStreetSegment(i,j);
                streetids.push_back(temp);
                
                StreetSegmentInfo sgi = getStreetSegmentInfo(temp);
            
            /*Check for adjacent intersections
             * Checking if the street segment is a one way
             * If true, checking if "from" is the current intersection to determine if the path exists
             * If false, checking if "from" is the current intersection, then insert the "to",since the
             * segment starts from there else insert the "from" since the intersection ends there */
                if (sgi.oneWay) {
                    if (sgi.from == i)
                        set.insert(sgi.to);
                } 
                else {
                    if (sgi.from == i)
                        set.insert(sgi.to);
                    else
                        set.insert(sgi.from);
                }
            }
         
            // Vector within a vector created with a vector of street segments indexed by the intersection id 
            id_with_Streetnames.push_back(streetids);
            
            // Vector of vectors created with all the adjacent intersections of each intersection
            adj = std::vector<unsigned>(set.begin(), set.end());
            adjacentIntersections.push_back(adj);
            
            // Temporary vectors cleared
            streetids.clear(); 
            adj.clear();
            set.clear();
        }    

        // 5. For increasing the performance of the function for finding street segments from street ids,
        // a vector of street segments vectors is created indexed by the street id        
        for(i=0;i<streetnum;i++){
            std::vector<unsigned> tempSegments;
            auto segments = StreetIDandStreetSegments.equal_range(i); // Gets street segment ids from the multimap for the corresponding street
            for (auto iter = segments.first; iter != segments.second; iter++){
                tempSegments.push_back(iter->second);
            }
            streetIDsandStreetSegments.push_back(tempSegments);
            tempSegments.clear();
        }
        
        for (i=0; i<POINum; i++){
            POINames.push_back(getPointOfInterestName(i));
        }
        
        // 4. Unordered map containing all the street IDs mapped to their intersections
        
        // Temporary set containing the intersection ids
        std::set<unsigned> tempIntersectionIds;
        
        // Temporary vectors containing street segments
        std::vector<unsigned>streetSegments;

        //unsigned count = getNumberOfStreetSegments();

        
        /* i= street ids
         *  Loop goes through all the street ids, finds all its street segments 
         * and puts its intersections in a temporary vector
         * The intersections of each street id are put into a vector which is put in a map */
        for (i=0;i<streetnum;i++){
            streetSegments = streetIDsandStreetSegments[i];
            for (auto iter = streetSegments.begin(); iter!=streetSegments.end();iter++){
//                StreetSegmentInfo sgi = getStreetSegmentInfo(*iter);
//                tempIntersectionIds.insert(sgi.to);
//                tempIntersectionIds.insert(sgi.from);                
                tempIntersectionIds.insert(streetSegmentIntersectionTo[*iter]);
                tempIntersectionIds.insert(streetSegmentIntersectionFrom[*iter]);                
            }
            std::vector<unsigned> intersections(tempIntersectionIds.begin(), tempIntersectionIds.end());
            
            for (auto iter = intersections.begin();iter!=intersections.end();iter++){
                StreetIDandIntersectionIDmap[i].push_back(*iter); // Intersections vector mapped with the street id as the key 
            }
            intersections.clear();
            streetSegments.clear();
            tempIntersectionIds.clear();    
        }          

        centerLat = (smallestLattitude + greatestLattitude) / 2;
        centerLon = (smallestLongitude + greatestLongitude) / 2;
        //centerCoordinates.x = centerLat * fastcos(centerLat) * DEG_TO_RAD;
        //centerCoordinates.y = centerLon * DEG_TO_RAD;
        
        centerCoordinates.x = EARTH_RADIUS_IN_METERS * fastcos(centerLat) * fastcos(centerLon) / 1000;
        centerCoordinates.y = EARTH_RADIUS_IN_METERS * fastcos(centerLat) * std::sin(centerLon * DEG_TO_RAD) / 1000;
    
//        intersectionSegments.resize(intersectionNum);
//        
//        for (i = 0; i< intersectionNum; i++){
//            std::vector<unsigned> adjNodes = find_adjacent_intersections(i);
//
//
//            std::vector<unsigned> testVec(intersectionNum, INT_MAX);
//            
//            for (auto itr = adjNodes.begin(); itr != adjNodes.end(); itr++){
//                vector<unsigned> streetSegmentsID;
//                std::vector<unsigned> streetSegments = find_intersection_street_segments(i);
//
//                for (auto itr2 = streetSegments.begin(); itr2 != streetSegments.end(); itr2++){
//                    StreetSegmentInfo sgi = getStreetSegmentInfo(*itr2);
//                    if (sgi.from == i && sgi.to == *itr)
//                        streetSegmentsID.push_back(*itr2);
//                    else if (sgi.to == i && sgi.from == *itr && !sgi.oneWay)
//                        streetSegmentsID.push_back(*itr2);
//                }
//
//                for (auto itr3 = streetSegmentsID.begin(); itr3 != streetSegmentsID.end(); itr3++){
//                    unsigned streetSegment = *itr3;
//
//                    double travelTime = streetSegmentTravelTime[streetSegment];
//
//                    if (testVec[*itr] == INT_MAX)
//                        testVec[*itr] = streetSegment;
//                    else if (streetSegmentTravelTime[testVec[*itr]] > travelTime)
//                        testVec[*itr] = streetSegment;                    
//                }
//            }
//        intersectionSegments[i] = testVec;
//        }
    }
    
    isStreetsDoneLoading = true;
    
    return load_success;
}

//close the map
void close_map() {
    closeStreetDatabase();
    isStreetsDoneLoading = false;
    streetNameIDmap.clear();
    adjacentIntersections.clear();
    id_with_Streetnames.clear();
    rtcoordinates.clear();
    StreetIDandIntersectionIDmap.clear();
    streetIDsandStreetSegments.clear();
    streetNames.clear();
    POINames.clear();
    streetSegmentTravelTime.clear();
    streetSegmentStreetID.clear();
    streetSegmentSpeedLimit.clear();
    streetSegmentIntersectionFrom.clear();
    streetSegmentIntersectionTo.clear();
    streetSegmentCurvePointCount.clear();
    streetSegmentLength.clear();
}

std::vector<unsigned> find_street_ids_from_name(std::string street_name) {
    /* Function finds all the pairs with the key as the street name from 
     * the multimap that was created 
     * Iterates through all the pairs and
     * puts the pairs' value (street id) in a vector */
    
    std::vector<unsigned> result;

    auto elements = streetNameIDmap.equal_range(street_name);
    for (auto itr = elements.first; itr != elements.second; ++itr) {
        result.push_back(itr->second);
    }
        
    return result;
}

std::vector<unsigned> find_intersection_street_segments(unsigned intersection_id) {
    
    // Calls the vector data structure to get the street segments  
    return id_with_Streetnames[intersection_id];
}

std::vector<std::string> find_intersection_street_names(unsigned intersection_id) {
    /* Stores all the street segments corresponding to the intersections in a vector
     * Goes through each street segment, and finds its street id 
     * Street ids are stored in another vector
     */
    unsigned i = 0;
    std::vector<unsigned> streetSegments = id_with_Streetnames[intersection_id];
    std::vector<std::string>streetNames;

    for (i = 0; i< streetSegments.size(); i++){
        unsigned streetId = streetSegmentStreetID[i];
        streetNames.push_back(getStreetName(streetId));
    }
    return streetNames;
}

bool are_directly_connected(unsigned intersection_id1, unsigned intersection_id2) {
    
    /* Calls adjacent intersection function to find all the adjacent intersections of the first intersection
     * Is connected if the second intersection is one of the adjacent intersections 
     * Returns false otherwise */
    
    if (intersection_id1 == intersection_id2) // Checks if intersections are the same
        return true;

    std::vector<unsigned> adjcent_intersections = find_adjacent_intersections(intersection_id1);

    for (auto itr = adjcent_intersections.begin(); itr != adjcent_intersections.end(); itr++) {
        if (*itr == intersection_id2)
            return true;
    }
    return false;
}

std::vector<unsigned> find_adjacent_intersections(unsigned intersection_id) {
    
    // Calls the vector data structure to find the adjacent intersections of the intersection
    return adjacentIntersections[intersection_id];
}

std::vector<unsigned> find_street_street_segments(unsigned street_id){
    
    // Calls the vector data structure to get all the street segments of the street id
    return streetIDsandStreetSegments[street_id];
}   

std::vector<unsigned> find_all_street_intersections(unsigned street_id) {
    
    /* Finds the pair with the respective street id as the key in the unordered map
     * Returns its value which is a vector containing the corresponding intersection ids */  
      return StreetIDandIntersectionIDmap.find(street_id)->second;
}
std::vector<unsigned> getPointOfInterestID(string pointOfInterestName)
{
    
          std::vector<unsigned> POIIDS;
            for (unsigned i = 0; i <getNumberOfPointsOfInterest(); i++) {
                if(pointOfInterestName==getPointOfInterestName(i))
                POIIDS.push_back(i);
            }
            return POIIDS;
}
//function to find 7 "poiname" point of interest closest to the source intersection
std::vector<unsigned> find_closest_pois_from_intersection(unsigned intersection_id, string poiname)
{
    std::vector<unsigned> POIID= getPointOfInterestID(poiname);
    std::vector<unsigned> closest_poi;
    LatLon pos_int=getIntersectionPosition(intersection_id);
    //define 7 flags to keep track of 7 pois
    int flag1, flag2 , flag3,flag4,flag5,flag6,flag7;
    flag1=flag2=flag3=flag4=flag5=flag6=flag7=-1;
    //comparing the distance to a Max value 
    int max1, max2, max3,max4,max5,max6,max7;
    max1=max2=max3=max4=max5=max6=max7=999999;   
    //looping through all the poiids
    for(auto itr= POIID.begin();itr!= POIID.end();itr++)
    {
        LatLon poi_pos=getPointOfInterestPosition(*itr);
        double dis= find_distance_between_two_points(pos_int,poi_pos);
        //cases to check the range of distance it lies in
        if(dis<=max1&&dis<max2&&dis<max3&&dis<max4&&dis<max5&&dis<max6&&dis<max7)
        {
            max7=max6;
            max6=max5;
            max5=max4;
            max4=max3;     
            max3=max2;
            max2=max1;
            max1=dis;
            flag7=flag6;
            flag6=flag5;
            flag5=flag4;
            flag4=flag3;
            flag3=flag2;
            flag2=flag1;
            flag1=*itr;
        }
        else if(dis>max1&&dis<=max2&&dis<max3&&dis<max4&&dis<max5&&dis<max6&&dis<max7)
        {
            max7=max6;
            max6=max5;
            max5=max4;
            max4=max3;     
            max3=max2;
            max2= dis;
            flag7=flag6;
            flag6=flag5;
            flag5=flag4;
            flag4=flag3;
            flag3=flag2;
            flag2=*itr;
        }
        
        else if(dis>max1&&dis>max2&&dis<=max3&&dis<max4&&dis<max5&&dis<max6&&dis<max7)
        {
            max7=max6;
            max6=max5;
            max5=max4;
            max4=max3;     
            max3=dis;
            flag7=flag6;
            flag6=flag5;
            flag5=flag4;
            flag4=flag3;
            flag3=*itr;
        }
        
        else if(dis>max1&&dis>max2&&dis>max3&&dis<=max4&&dis<max5&&dis<max6&&dis<max7)
        {
            max7=max6;
            max6=max5;
            max5=max4;
            max4=dis;
            flag7=flag6;
            flag6=flag5;
            flag5=flag4;
            flag4=*itr;
        }
        else if(dis>max1&&dis>max2&&dis>max3&&dis>max4&&dis<=max5&&dis<max6&&dis<max7)
        {
            max7=max6;
            max6=max5;
            max5=dis;
            flag7=flag6;
            flag6=flag5;
            flag5=*itr;
        }
        else if(dis>max1&&dis>max2&&dis>max3&&dis>max4&&dis>max5&&dis<=max6&&dis<max7)
        {
            max7=max6;
            max6=dis;
            flag7=flag6;
            flag6=*itr;
        }
        else if(dis>max1&&dis>max2&&dis>max3&&dis>max4&&dis>max5&&dis>max6&&dis<=max7)
        {
            max7=dis;
            flag7=*itr;
        }
         
    }
    
    if(flag1!=-1)
        closest_poi.push_back(flag1);
        
    if(flag2!=-1)
        closest_poi.push_back(flag2);
        
    if(flag3!=-1)
        closest_poi.push_back(flag3);
    
    if(flag4!=-1)
        closest_poi.push_back(flag4);
    
    if(flag5!=-1)
        closest_poi.push_back(flag5);
    
    if(flag6!=-1)
        closest_poi.push_back(flag6);   
    
    if(flag7!=-1)
        closest_poi.push_back(flag7);

    return closest_poi;
}

std::vector<unsigned> get_closest_intersection_poiids(std::vector<unsigned> POIIds)
{
    vector<unsigned> intersection_ids;
    
    for(auto itr=POIIds.begin();itr!=POIIds.end();itr++)
    {
        LatLon pos= getPointOfInterestPosition (*itr);
        unsigned intersection_id=find_closest_intersection(pos);
        intersection_ids.push_back(intersection_id);
    }
    return intersection_ids;
}

std::vector<unsigned> find_intersection_ids_from_street_names(std::string street_name1, std::string street_name2) {    
    /* Function first finds the street ids of both street names and puts it in a vector
     * For each street id of both street name, all the intersections are found and stored in two vectors
     * Both vectors of intersections are compared to check if the ids match
     */
    
    // Streets ids of both street names
    std::vector<unsigned> streetID1 = find_street_ids_from_name(street_name1);
    std::vector<unsigned> streetID2 = find_street_ids_from_name(street_name2);
    
    std::vector<unsigned>commonIntersections;
    std::vector<unsigned> intersection1;
    std::vector<unsigned>intersection2;

    unsigned i = 0;
       
    // for the first street
    for (i = 0; i < streetID1.size(); i++) {
        // Function call to find the intersections of the street
        // Temporary vector to store intersection ids of that street id
        std::vector<unsigned> tempIntersections = find_all_street_intersections(streetID1[i]); 
        
        // Final vector to store all the intersection ids of all the street ids 
        intersection1.insert(intersection1.end(), tempIntersections.begin(), tempIntersections.end()); 
    }

    // For the second street
    for (i = 0; i < streetID2.size(); i++) {
        std::vector<unsigned> tempIntersections = find_all_street_intersections(streetID2[i]);
        intersection2.insert(intersection2.end(), tempIntersections.begin(), tempIntersections.end());
    }

    // Compares the values of both vectors to checks for similarities
    for (i = 0; i < intersection1.size(); i++) {
        for (unsigned j = 0; j < intersection2.size(); j++) {
            if (intersection1[i] == intersection2[j]) {
                commonIntersections.push_back(intersection1[i]);
            }
        }
    }
    return commonIntersections;
}

double find_distance_between_two_points(LatLon point1, LatLon point2) {

    //This could break if the two points are on different sides of the poles or the equator
    //Current implementation holds and will hopefully hold
    
    /*
     * Implemented as said in the milestone1 document
     * 
     * All degrees to be converted into radians
     * 
     * (x, y) = (lon · cos(latavg), lat) 
     * 
     * d = R ·sqrt( (y2 − y1)^2 + (x2 − x1)^2)
     * 
     *  */
        

    long double latavg = (point1.lat + point2.lat) / 2 ;
    long double yavg, xavg;
    
    xy pt1, pt2;
    pt1.x = point1.lon * fastcos(latavg) * DEG_TO_RAD;
    pt1.y = point1.lat * DEG_TO_RAD;
    pt2.x = point2.lon * fastcos(latavg) * DEG_TO_RAD;
    pt2.y = point2.lat * DEG_TO_RAD;

    yavg = pt2.y - pt1.y;
    yavg *= yavg;
    xavg = pt2.x - pt1.x;
    xavg *= xavg;
    return EARTH_RADIUS_IN_METERS * sqrt(yavg + xavg);
}

double find_street_segment_length(unsigned street_segment_id) {
    double length = 0;

    // Finds the distance between every curved point. 
    // If there are no curved points, the only two end points are intersection to and intersection from
    // Any curved point is added in between these two points.
        
    unsigned count = streetSegmentCurvePointCount[street_segment_id];

    std::vector<LatLon> pointsVector;

    pointsVector.push_back(getIntersectionPosition(streetSegmentIntersectionFrom[street_segment_id])); // Adds from intersection position

    //Adds location of any curved point if it exists
    if (count > 0) {
        for (unsigned i = 0; i < count; i++) {
            pointsVector.push_back(getStreetSegmentCurvePoint(street_segment_id, i));
        }
    }
    
    //Adds to intersection location
    pointsVector.push_back(getIntersectionPosition(streetSegmentIntersectionTo[street_segment_id]));

    //iterates through the list created above and sums up the distance
    for (auto itr = pointsVector.begin() + 1; itr != pointsVector.end(); itr++) {
        length += find_distance_between_two_points(*(itr - 1), *itr);
    }

    return length;
}

double find_street_length(unsigned street_id) {

    double length = 0;

    //Sums up the distance of all the street segments in the street
    
    std::vector<unsigned> streetSegments = find_street_street_segments(street_id);

    for (auto itr = streetSegments.begin(); itr != streetSegments.end(); itr++) {
        length += findStreetSegmentLength(*itr);
    }

    return length;
}

double find_street_segment_travel_time(unsigned street_segment_id) {
    double distance = findStreetSegmentLength(street_segment_id) * 0.001; //Convert to km

    //Uses the below formula
    //Time = distance / speed
    
    return (distance / streetSegmentSpeedLimit[street_segment_id]) * 60;                                     //uses above formula
}


unsigned find_closest_point_of_interest(LatLon my_position) {
    /* Goes through all the point of interest, finds its Lat/Lon position
     * Using the distance between two points function, finds the distance between 
     * the point of interest and compares the value for minimum distance */
    
    // Arbritrary value for the minimum distance that the point of interest must be closer than
    int min = 90000000; 
    unsigned poi = 0;
    LatLon pointsofinterest;
    int newdistance;
    for (unsigned i = 0; i < getNumberOfPointsOfInterest(); i++) {
        pointsofinterest = getPointOfInterestPosition(i);
        newdistance = find_distance_between_two_points(pointsofinterest, my_position);
        if (newdistance < min) {
            min = newdistance;
            poi = i;
        }
    }
    return poi;
}


unsigned find_closest_intersection(LatLon my_position) {
    // uses r theta coordinate system to find the closest point 
    
    rtheta coordinates = map_to_polar_coordinates(my_position);
    
    //Ans here stores the data from the previous find point and is used like a temporary cache to avoid running through the vales in theta +- range +- 1
    std::pair<double, unsigned> ans = std::make_pair(500000000, 0);

    std::vector<unsigned> list;
    bool found = false;
    double rangeT = 0, rangeR = 10; //Initial values - rangeT is for theta and rangeR is for radius
    while (!found) {
        //Going for theta + range
        auto elements = rtcoordinates.equal_range(coordinates.theta + rangeT);
        for (auto itr = elements.first; itr != elements.second; itr++) {            
                list.push_back((itr->second).id); //Adds to vector of points to check
        }

        //Going for theta - range
        if (rangeT != 0) {
            auto elements = rtcoordinates.equal_range(coordinates.theta - rangeT);
              for (auto itr = elements.first; itr != elements.second; itr++) {            
                    list.push_back((itr->second).id); //Adds to vector of points to check
            }
        } 
        
        //Check if you can find the point
        ans = findPoint(list, my_position, rangeR, ans.first, ans.second); //ans is the previously cached values
        
        if (ans.first < rangeR){ // if -1 is returned, point is not found. Else returned value is intersection
            found = true;
            return ans.second;
        } else {
            
            //Increment R and theta range values for next cycle check. Happens only when it is not found 
            rangeT += 1;
            if (rangeT < 15)
                rangeR *= 1.1;
            else
                rangeR += 100;
            list.clear();
        }
    }
    return 0;  
}

rtheta map_to_polar_coordinates(LatLon coordinates) {

    xy pt;
    rtheta polarPts;
    long double R = EARTH_RADIUS_IN_METERS / 1000;
    double tempth;
    
    //First converting into x,y coordinates
    pt.x = R * cos(coordinates.lat * DEG_TO_RAD) * cos(coordinates.lon * DEG_TO_RAD);
    pt.y = R * cos(coordinates.lat * DEG_TO_RAD) * sin(coordinates.lon * DEG_TO_RAD);

    //Moving center from the origin to the location if intersection(0) - Yes it is weird and yes it is a bug which I didn't realize until the last moment. It works but changing it to
    //the center of the map (toronto) would make it faster
    pt.x -= intersection0Coordinates.x;
    pt.y -= intersection0Coordinates.y;

    //Now converting into polar coordinates
    polarPts.r = sqrt(pow(pt.x, 2) + pow(pt.y, 2));
    tempth = atan(pt.y / pt.x) * 1 / DEG_TO_RAD;     //Converting back to degrees

    //Round it to one decimal places
    polarPts.r = (int) round(polarPts.r);
    polarPts.theta = (int) round(tempth * 10);
    //polarPts.theta = polarPts.theta / 10;

    return polarPts;
}

void hash_into_map(unsigned intersectionID) {

    LatLon intersectionLocation = getIntersectionPosition(intersectionID);

    //For calculating center of the map
    if (intersectionLocation.lat > greatestLattitude)
        greatestLattitude = intersectionLocation.lat;
    if (intersectionLocation.lon > greatestLongitude)
        greatestLongitude = intersectionLocation.lon;
    if (intersectionLocation.lat < smallestLattitude)
        smallestLattitude = intersectionLocation.lat;
    if (intersectionLocation.lon < smallestLongitude)
        smallestLongitude = intersectionLocation.lon;

    //Get R and theta coordinates
    rtheta coordinates = map_to_polar_coordinates(intersectionLocation);

    //Store into data struct
    rtdata data = {(double) coordinates.r, intersectionID};

    //Stores into hash map
    rtcoordinates.insert(std::make_pair(coordinates.theta, data));
}

std::pair<double, unsigned> findPoint(std::vector<unsigned> list, LatLon myPosition, double rRange, double shortest_distance, unsigned id_of_distance) {

    double temp;
    
    //Iterates through the list provided and finds the shortest distance. Returns the value to the calling function.
    
    for (auto itr = list.begin(); itr != list.end(); itr++) {
        temp = find_distance_between_two_points(getIntersectionPosition(*itr), myPosition);
        
        if (temp < shortest_distance) {
            shortest_distance = temp;
            id_of_distance = (int) *itr;
        }         
    }
    return std::make_pair(shortest_distance, id_of_distance);
}

 
double fastcos(double angle){
     
    /* Function checks if the angle is negative, between 0-90, or 90 -180 
    * and returns the cosine value based on the angle using the array defined */
    if(angle < 0)
        angle *= -1;
    
    if (angle >= 0 && angle < 90)
        return cosArray[(unsigned)(angle * 1000)];
    if (angle >= 90 && angle < 180)
        return -1 * cosArray[(unsigned)((90-angle) * 1000)];
    return 0;
}

std::string find_street_name_from_street_segmentID(unsigned street_segment_id) {
    return streetNameSegmentIDmap[street_segment_id];
}

double findStreetSegmentTravelTime(unsigned segmentID) {
    return streetSegmentTravelTime[segmentID];
}

double findStreetSegmentLength(unsigned segmentID) {
    return streetSegmentLength[segmentID];
}
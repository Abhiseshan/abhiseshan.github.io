/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   LoadWeatherData.h
 * Author: abhi
 *
 * Created on March 1, 2016, 2:47 PM
 */

#ifndef LOADWEATHERDATA_H
#define LOADWEATHERDATA_H

extern double temperatureData;
extern bool weatherDataReady;


void loadWeather(LatLon coordinates);

#endif /* LOADWEATHERDATA_H */


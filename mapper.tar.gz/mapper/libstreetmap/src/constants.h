#include <string>
#include "easygl_constants.h"

#define ABHI

#pragma once
/* 
 * File:   drawing_constants.h
 * Author: abhi
 *
 * Created on February 6, 2016, 12:26 PM
 * 
 * File describes different constants/state ids used
 */

#ifndef CONSTANTS_H
#define CONSTANTS_H

/* Constants defining hamburger menu state*/
const static int HAMBURGER_MENU_COLLAPSED = 0;
const static int HAMBURGER_MENU_EXPANDED = 1;
const static int HAMBURGER_MENU_ISEXPANDING = 2;
const static int HAMBURGER_MENU_ISCOLLAPSING = 3;

/* For detecting input*/
const static int MAX_ALLOWED_ASCII_CHAR = 122;
const static int MIN_ALLOWED_ASCII_CHAR = 32;
const static int BACK_SPACE_CHAR = 65288;
const static int ENTER_CHAR = 65293;
const static int LEFT_ARROW_CHAR = 65361;
const static int UP_ARROW_CHAR = 65362;
const static int RIGHT_ARROW_CHAR = 65363;
const static int DOWN_ARROW_CHAR = 65364;
const static double PI =3.14159265359;
/* States*/
const static int STARTUP = 0;
const static int LOOP = 1;

const static std::string apiID = "4805980c3c170bc0dcb39db79bf940eb";

#define EARTH_RADIUS_IN_METERS 6372797.560856
#define DEG_TO_RAD 0.017453292519943295769236907684886
#define ZOOM_RATIO 2.777919482
#define MAX_COS_VALUES 90001

const static double ARROW_SIZE = 0.001;
const static double TURN_TIME = 0.25;
const static double HEURISTIC_TURN_TIME = 0.5;
const static double HEURISTIC_WEIGHT = 1.8;

#define INTERSECTION_OVERFLOW 0.000002
#define BOUNDS_OVERFLOW 0.0001

#ifdef ABHI
const static std::string TORONTO_STREETS = "/home/abhi/ece297/maps/toronto.streets.bin";
const static std::string TORONTO_OSM = "/home/abhi/ece297/maps/toronto.osm.bin";
const static std::string CAIRO_STREETS = "/home/abhi/ece297/maps/cairo_egypt.streets.bin";
const static std::string CAIRO_OSM = "/home/abhi/ece297/maps/cairo_egypt.osm.bin";
const static std::string HAMILTON_STREETS = "/home/abhi/ece297/maps/hamilton_canada.streets.bin";
const static std::string HAMILTON_OSM = "/home/abhi/ece297/maps/hamilton_canada.osm.bin";
const static std::string MOSCOW_STREETS = "/home/abhi/ece297/maps/moscow.streets.bin";
const static std::string MOSCOW_OSM = "/home/abhi/ece297/maps/moscow.osm.bin";
const static std::string NEWYORK_STREETS = "/home/abhi/ece297/maps/newyork.streets.bin";
const static std::string NEWYORK_OSM = "/home/abhi/ece297/maps/newyork.osm.bin";
const static std::string SAINT_HELENA_STREETS = "/home/abhi/ece297/maps/saint_helena.streets.bin";
const static std::string SAINT_HELENA_OSM = "/home/abhi/ece297/maps/saint_helena.osm.bin";
const static std::string TORONTO_CANADA_STREETS = "/home/abhi/ece297/maps/toronto_canada.streets.bin";
const static std::string TORONTO_CANADA_OSM = "/home/abhi/ece297/maps/toronto_canada.osm.bin";
const static std::string LONDON_STREETS = "/home/abhi/ece297/maps/london_england.streets.bin";
const static std::string LONDON_OSM = "/home/abhi/ece297/maps/london_england.osm.bin";

#endif /* ABHI */

#ifdef EECG
const static std::string TORONTO_STREETS = "/cad2/ece297s/public/maps/toronto.streets.bin";
const static std::string TORONTO_OSM = "/cad2/ece297s/public/maps/toronto.osm.bin";
const static std::string CAIRO_STREETS = "/cad2/ece297s/public/maps/cairo_egypt.streets.bin";
const static std::string CAIRO_OSM = "/cad2/ece297s/public/maps/cairo_egypt.osm.bin";
const static std::string HAMILTON_STREETS = "/cad2/ece297s/public/maps/hamilton_canada.streets.bin";
const static std::string HAMILTON_OSM = "/cad2/ece297s/public/maps/hamilton_canada.osm.bin";
const static std::string MOSCOW_STREETS = "/cad2/ece297s/public/maps/moscow.streets.bin";
const static std::string MOSCOW_OSM = "/cad2/ece297s/public/maps/moscow.osm.bin";
const static std::string NEWYORK_STREETS = "/cad2/ece297s/public/maps/newyork.streets.bin";
const static std::string NEWYORK_OSM = "/cad2/ece297s/public/maps/newyork.osm.bin";
const static std::string SAINT_HELENA_STREETS = "/cad2/ece297s/public/maps/saint_helena.streets.bin";
const static std::string SAINT_HELENA_OSM = "/cad2/ece297s/public/maps/saint_helena.osm.bin";
const static std::string TORONTO_CANADA_STREETS = "/cad2/ece297s/public/maps/toronto_canada.streets.bin";
const static std::string TORONTO_CANADA_OSM = "/cad2/ece297s/public/maps/toronto_canada.osm.bin"; 
const static std::string LONDON_STREETS = "/cad2/ece297s/public/maps/london_england.streets.bin";
const static std::string LONDON_OSM = "/cad2/ece297s/public/maps/london_england.osm.bin";

#endif /* EECG */
#endif /* DRAWING_CONSTANTS_H */

#include "LoadOSMData.h"

//Different vectors containing positions of stuff
std::vector<std::vector<LatLon>> HWMotorways;
std::vector<std::vector<LatLon>> HWTrunk;
std::vector<std::vector<LatLon>> HWPrimary;
std::vector<std::vector<LatLon>> HWSecondary;
std::vector<std::vector<LatLon>> HWTertiary;
std::vector<std::vector<LatLon>> HWUnclassified;
std::vector<std::vector<LatLon>> HWResidential;
std::vector<std::vector<LatLon>> HWService;
std::vector<std::vector<LatLon>> HWMotorwaysLink;
std::vector<std::vector<LatLon>> HWTrunkLink;
std::vector<std::vector<LatLon>> HWSecondaryLink;
std::vector<std::vector<LatLon>> HWTertiaryLink;
std::vector<std::vector<LatLon>> HWPedestrian;
std::vector<std::vector<LatLon>> OSMBuildings;
std::vector<std::vector<LatLon>> Runways;
std::vector<std::vector<LatLon>> Taxiways;
std::vector<std::vector<LatLon>> BloorDanforthSubway;
std::vector<std::vector<LatLon>> YongeUniversitySpadinaSubway;
std::vector<std::vector<LatLon>> ScarboroughLine;
std::vector<std::vector<LatLon>> SheppardLine;
std::vector<std::vector<LatLon>> Railways;
std::vector<std::vector<LatLon>> BicyclePaths;

bool isOSMDoneLoading = false;

//For Thread safety
std::mutex thread_lock;
std::mutex thread_lock3;

//Thread Functions
void getRailwayInformation(int);
void getAirportInformation(int);
void getBicycleInformation(int);
void getOtherRoadInformation(int);

void loadOSMdatabase(std::string OSMBinLocation){
    loadOSMDatabaseBIN(OSMBinLocation);
              
    int i, numWays = getNumberOfWays();

    //Definition of different threads. Running them parallely so the total load time is just as slow
    //as the slowest function
    thread railwayThread(getRailwayInformation, numWays);
    thread airportThread(getAirportInformation, numWays);
    thread bicycleThread(getBicycleInformation, numWays);
    thread otherRoadThread(getOtherRoadInformation, numWays);
    
    for (i = 0; i < numWays; i++){
        const OSMWay* way = getWayByIndex(i);
        if (way->hasTag(osmdb.wayTags().getIndexForKeyString("highway"))){
            if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("highway"), osmdb.wayTags().getIndexForValueString("motorway"))){
                HWMotorways.push_back(osmdb.extractPoly(*way));
            }else if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("highway"), osmdb.wayTags().getIndexForValueString("trunk"))){
                HWTrunk.push_back(osmdb.extractPoly(*way));
            }else if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("highway"), osmdb.wayTags().getIndexForValueString("primary"))){
                HWPrimary.push_back(osmdb.extractPoly(*way));
            }else if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("highway"), osmdb.wayTags().getIndexForValueString("secondary"))){
                HWSecondary.push_back(osmdb.extractPoly(*way));
            }else if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("highway"), osmdb.wayTags().getIndexForValueString("tertiary"))){
                HWTertiary.push_back(osmdb.extractPoly(*way));
            }else if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("highway"), osmdb.wayTags().getIndexForValueString("unclassified"))){
                HWUnclassified.push_back(osmdb.extractPoly(*way));
            }else if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("highway"), osmdb.wayTags().getIndexForValueString("residential"))){
                HWResidential.push_back(osmdb.extractPoly(*way));
            }else if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("highway"), osmdb.wayTags().getIndexForValueString("service"))){
                HWService.push_back(osmdb.extractPoly(*way));
            }
        }
    }
    
    //Joining the threads to complete loading
    railwayThread.join();
    airportThread.join();
    bicycleThread.join();
    otherRoadThread.join();
    isOSMDoneLoading = true;
}

//Getting railway information from layer1
void getRailwayInformation(int numWays){
    
    for (int i = 0; i < numWays; i++){
        const OSMWay* way = getWayByIndex(i);
        if (way->hasTag(osmdb.wayTags().getIndexForKeyString("railway"))){
            if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("railway"), osmdb.wayTags().getIndexForValueString("subway"))){
                std::string lineName = osmdb.extractName(i);
                if (lineName == "Bloor-Danforth Line")
                    BloorDanforthSubway.push_back(osmdb.extractPoly(*way));
                else if (lineName == "Yonge-University-Spadina Line")
                    YongeUniversitySpadinaSubway.push_back(osmdb.extractPoly(*way));
                else if (lineName == "Sheppard Line")
                    SheppardLine.push_back(osmdb.extractPoly(*way));
                else if (lineName == "Scarborough RT")
                    ScarboroughLine.push_back(osmdb.extractPoly(*way));
            }
            if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("railway"), osmdb.wayTags().getIndexForValueString("rail"))){
                Railways.push_back(osmdb.extractPoly(*way));
            }
            if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("railway"), osmdb.wayTags().getIndexForValueString("station"))){
                thread_lock.lock();
                OSMBuildings.push_back(osmdb.extractPoly(*way));
                thread_lock.unlock();
            }
        }
    }
}

//getting airport information from layer1
void getAirportInformation(int numWays){
    
    for (int i = 0; i < numWays; i++){
        const OSMWay* way = getWayByIndex(i);
        if (way->hasTag(osmdb.wayTags().getIndexForKeyString("aeroway"))){
            if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("aeroway"), osmdb.wayTags().getIndexForValueString("terminal"))){
                thread_lock.lock();
                OSMBuildings.push_back(osmdb.extractPoly(*way));
                thread_lock.unlock();
            }else if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("aeroway"), osmdb.wayTags().getIndexForValueString("hangar"))){
                thread_lock.lock();
                OSMBuildings.push_back(osmdb.extractPoly(*way));
                thread_lock.unlock();
            }else if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("aeroway"), osmdb.wayTags().getIndexForValueString("runway"))){
                Runways.push_back(osmdb.extractPoly(*way));
            }else if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("aeroway"), osmdb.wayTags().getIndexForValueString("taxiway"))){
                Taxiways.push_back(osmdb.extractPoly(*way));
            }
        }
    }
}

//get bicycle information
void getBicycleInformation(int numWays){
    for (int i = 0; i < numWays; i++){
        const OSMWay* way = getWayByIndex(i);
        if (way->hasTag(osmdb.wayTags().getIndexForKeyString("cycleway"))){
            thread_lock3.lock();
            if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("cycleway"), osmdb.wayTags().getIndexForValueString("lane"))){
                BicyclePaths.push_back(osmdb.extractPoly(*way));
            }else if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("cycleway"), osmdb.wayTags().getIndexForValueString("track"))){
                BicyclePaths.push_back(osmdb.extractPoly(*way));
            }else if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("cycleway"), osmdb.wayTags().getIndexForValueString("share_busway"))){
                BicyclePaths.push_back(osmdb.extractPoly(*way));
            }else if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("cycleway"), osmdb.wayTags().getIndexForValueString("shared_lane"))){
                BicyclePaths.push_back(osmdb.extractPoly(*way));
            }
            thread_lock3.unlock();
        }
    }
}

void getOtherRoadInformation(int numWays){
    for (int i = 0; i < numWays; i++){
        const OSMWay* way = getWayByIndex(i);
        if (way->hasTag(osmdb.wayTags().getIndexForKeyString("highway"))){
            if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("highway"), osmdb.wayTags().getIndexForValueString("motorway_link"))){
                HWMotorwaysLink.push_back(osmdb.extractPoly(*way));
            }else if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("highway"), osmdb.wayTags().getIndexForValueString("trunk_link"))){
                HWTrunkLink.push_back(osmdb.extractPoly(*way));
            }else if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("highway"), osmdb.wayTags().getIndexForValueString("secondary_link"))){
                HWSecondaryLink.push_back(osmdb.extractPoly(*way));
            }else if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("highway"), osmdb.wayTags().getIndexForValueString("tertiary_link"))){
                HWTertiaryLink.push_back(osmdb.extractPoly(*way));
            }else if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("highway"), osmdb.wayTags().getIndexForValueString("pedestrian"))){
                HWPedestrian.push_back(osmdb.extractPoly(*way));
            }else if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("highway"), osmdb.wayTags().getIndexForValueString("footway"))){
                HWPedestrian.push_back(osmdb.extractPoly(*way));
            }else if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("highway"), osmdb.wayTags().getIndexForValueString("steps"))){
                HWPedestrian.push_back(osmdb.extractPoly(*way));
            }else if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("highway"), osmdb.wayTags().getIndexForValueString("path"))){
                HWPedestrian.push_back(osmdb.extractPoly(*way));
            }else if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("highway"), osmdb.wayTags().getIndexForValueString("track"))){
                HWPedestrian.push_back(osmdb.extractPoly(*way));
            } else if (way->hasTagWithValue(osmdb.wayTags().getIndexForKeyString("highway"), osmdb.wayTags().getIndexForValueString("cycleway"))){
                thread_lock3.lock();
                BicyclePaths.push_back(osmdb.extractPoly(*way));
                thread_lock3.unlock();
            }
        }
    }
}

//clears all vectors. Necessary for loading multiple maps.
void destroyOSMdatabase(){
    isOSMDoneLoading = false;
    HWMotorways.clear();
    HWPrimary.clear();
    HWResidential.clear();
    HWSecondary.clear();
    HWService.clear();
    HWTertiary.clear();
    HWTrunk.clear();
    HWUnclassified.clear();
    HWMotorwaysLink.clear();
    HWPedestrian.clear();
    HWSecondaryLink.clear();
    HWTertiaryLink.clear();
    HWTrunkLink.clear();
    OSMBuildings.clear();
    Runways.clear();
    Taxiways.clear();
    BloorDanforthSubway.clear();
    YongeUniversitySpadinaSubway.clear();
    ScarboroughLine.clear();
    SheppardLine.clear();
    Railways.clear();
    BicyclePaths.clear();
    closeOSMDatabase();
}
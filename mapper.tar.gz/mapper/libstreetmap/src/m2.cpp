#include "m2.h"
#include "m1.cpp"
#include "graphics.h"
#include "LatLon.h"
#include <string>
#include <X11/Xlib.h>
#include "LoadWeatherData.h"

std::vector<std::string> mapNames;
t_bound_box currentCoords; 
int currentState = STARTUP; 
string searchString = ""; 
string beforeSeg = "";
string streetsBin = "";
string osmBin = "";
string temperature = "-";

//Vectors to store highlighted features
vector<unsigned> highlightedStreetID;
vector<unsigned> highlightedIntersection;
vector<unsigned> highlightedIntersectionInfo;
std::vector<unsigned> highlightedPath;
std::vector<unsigned>POIIDS;
bool mapNotFound = false;
unsigned atVectorPos = 0;

unsigned intersection1 = INT_MAX, intersection2 = INT_MAX, pendingIntersection = INT_MAX;
std::string POIName = "", pendingPOIName = "";

//Draws the main map window with the Search Bar and Buttons
void draw_map(){
    //Load Map names into the vector
    mapNames.push_back("Toronto");
    mapNames.push_back("New York");
    mapNames.push_back("Cairo");
    mapNames.push_back("Hamilton");
    mapNames.push_back("Moscow");
    mapNames.push_back("Saint Helena");
    mapNames.push_back("Golden Horseshoe");
    mapNames.push_back("London");
    
    //Open the window
    init_graphics(" Crapple Maps ", GAINSBORO);
    t_bound_box initialCoords = t_bound_box(0,0,1000,1000);
    set_visible_world(initialCoords);
    set_mouse_move_input(true);
    set_keypress_input(true);
    setfontsize(5);
    drawSearchBar();   
    drawButtons();
    event_loop(act_on_mousebutton, NULL, act_on_keypress, drawscreen);            
    close_graphics();
    mapNames.clear();
}

//Draws the features included in the map
void drawscreen (void) {
    set_draw_mode (DRAW_NORMAL);  
    clearscreen();  
    
    static int count;
    
    count++;
    
    // Draws initial start up screen asking user to enter city name
    if (currentState == STARTUP){
        drawStartup();
    } 
    else {
        if (weatherDataReady){
            std::stringstream ss;
            ss << fixed << setprecision( 1 ) << temperatureData;
            temperature = ss.str() + "C";
        }
        flushinput();
        drawWeather(temperature);
        
        setlinestyle (SOLID);
        
        // Draws features like parks,lakes,etc
        drawWaterBodies();      
        drawIslands(); 
        drawGreenery();
        
        
        drawBuildingsAndUnknown(); // Draws buildings and unknown features
        drawOSMBuildings();  // Draws airport and railway stations
        drawAirportRunway(); // Draws airport runways
        
        // Draws Taxiways and Railway line
        drawPaths(2, LIGHTSTEELBLUE, Taxiways);
        drawPaths(1, SILVER, Railways);
        
        
        /* Drawing of different streets at different zoom levels
         * Main streets like motorways, secondary and their links are drawn first
         * As the user zooms in further, small streets are drawn like tertiary, residential,etc
         * All streets are visible after zoom level 7 
         * The thickness of the streets also increases based on zoom level */
        if (currentZoomLevel() >=7) 
        {
            drawPaths(15, WHITE, HWService);
            drawPaths(15, WHITE, HWUnclassified);
            drawPaths(1, SILVER, HWPedestrian);        
        }
        
        if (currentZoomLevel() >=6){
            if (currentZoomLevel()<=7)
                drawPaths(6, WHITE, HWResidential);
            else
                drawPaths(15, WHITE, HWResidential);
        }
        
        if( currentZoomLevel()>=4)
        {
            if (currentZoomLevel()<=7){
                setlinewidth(6);
                drawPaths(6, WHITE, HWPrimary);
                drawPaths(6, WHITE, HWTrunk);
                drawPaths(6, WHITE, HWTertiary);
            }
            else{
                drawPaths(15, WHITE, HWPrimary);
                drawPaths(15, WHITE, HWTrunk);
                drawPaths(15, WHITE, HWTertiary);
            }
        
        }
        
        if (currentZoomLevel()<= 6){           
            drawPaths(3, GOLDENROD, HWMotorwaysLink);
            drawPaths(3, IVORY, HWSecondaryLink);
            drawPaths(3, IVORY, HWTertiaryLink);
            drawPaths(3, IVORY, HWTrunkLink);           
            drawPaths(3, WHITE, HWSecondary);
            drawPaths(4, DARKORANGE, HWMotorways);
        }
        else{
            drawPaths(8, GOLDENROD, HWMotorwaysLink);
            drawPaths(8, IVORY, HWSecondaryLink);
            drawPaths(8, IVORY, HWTertiaryLink);
            drawPaths(8, IVORY, HWTrunkLink);          
            drawPaths(12, WHITE, HWSecondary);
            drawPaths(12, DARKORANGE, HWMotorways);
        }
        
                
        /* Drawing highlighted street after user searches for it
         * Keeps it highlighted until dismissed by the user despite zoom level*/
        
        if (!highlightedStreetID.empty()){            
            setcolor(MEDIUMPURPLE);
            setlinewidth(10);
            drawHighlightedStreet(highlightedStreetID[atVectorPos]);
        }
        
        if (!highlightedPath.empty()){
            setcolor(RED);
            for (auto itr = highlightedPath.begin(); itr != highlightedPath.end(); itr++)
                drawHighlightedStreetSegment(*itr);
        }
               
        // Points of interests drawn
        drawPointofInterest();
        
        // Draws the points of interest searched by the user
        if(!POIIDS.empty())
        {
            setcolor(PURPLE);
            for (auto itr = POIIDS.begin(); itr != POIIDS.end(); itr++){
                LatLon location= getPointOfInterestPosition(*itr);
                drawHighlightedIntersectionAndPOI(location);               
            }
        }
        
        // Highlights the intersection when searched through street names by the user
        if (!highlightedIntersection.empty()){
            for (auto iter = highlightedIntersection.begin(); iter != highlightedIntersection.end();iter++){
                LatLon intersectionPosition = getIntersectionPosition(*iter);
                setcolor(DARKORCHID);
                drawHighlightedIntersectionAndPOI(intersectionPosition);
            }              
        }
        
        // Highlights the intersection selected by the user
        if (!highlightedIntersectionInfo.empty()){
            setcolor(MEDIUMPURPLE);
            setlinewidth(5);
            setlinestyle (SOLID);
            for (auto iter2 = highlightedIntersectionInfo.begin(); iter2 != highlightedIntersectionInfo.end(); iter2++){
                drawHighlightedStreetSegment(*iter2);
            }
        }
        // Side Bar options
        
        // 1.Draw subways only in toronto 
        if ((osmBin == TORONTO_CANADA_OSM || osmBin == TORONTO_OSM) && getMenuOptionStatus(MENU_SUBWAY))
            drawTorontoSubways();
        
        // 2.Draws bicycle lanes
        if (getMenuOptionStatus(MENU_BIKE))
            drawPaths(2, WEBGREEN, BicyclePaths);
        
        // 3.Draw gas stations
        if (getMenuOptionStatus(MENU_GASSTATIONS))
            drawGasStations();
        // 4.Draw cafes    
        if(getMenuOptionStatus(MENU_CAFE))
            drawCafes();

        if(getMenuOptionStatus(MENU_HOSP))
            drawHospitals();     
        
        // Street names written on the streets
        // One way streets indicated
        if (currentZoomLevel() >=7) 
            drawStreetNamesAndArrows();
        
        flushinput();   
    }
}

/* Function to highlight the street searched by the user
 * Finds the street segments in the street, and draws each segment */

void drawHighlightedStreet(unsigned streetid){
    vector<unsigned> searchStreetSegmentIDS = find_street_street_segments(streetid);
    for (auto itr = searchStreetSegmentIDS.begin(); itr != searchStreetSegmentIDS.end(); itr++){
        drawHighlightedStreetSegment(*itr);
    }                        
}

// Highlights the segments of a street searched by the user
void drawHighlightedStreetSegment(unsigned i)
{   
    /* Draws a line from the start of the segment to the first curve point
     * Then connects consecutive curve points through a line
     * Finally connects the last curve point to the end of the segment */
     
    StreetSegmentInfo streetseg=getStreetSegmentInfo(i); 
    unsigned count = streetseg.curvePointCount;
    unsigned start= streetseg.from;
    unsigned end  = streetseg.to;
    
    // Finds the position of the start in degrees and converts it to x and y coordinates
    LatLon position1=getIntersectionPosition(start);
    t_point point1=getAbsoluteXYPos(position1);
    
    for(unsigned k=0;k<count;k++)
    {
        LatLon position2=getStreetSegmentCurvePoint(i,k);
        t_point point2=getAbsoluteXYPos(position2);
        drawline(point1,point2);
        point1=point2;
    }
    t_point point2=getAbsoluteXYPos(getIntersectionPosition(end));
    drawline(point1,point2);
    flushinput();
}

/* Draws the welcome screen
 * Prompts user to enter the city wanted */
void drawStartup(){
    clearscreen();
    drawPopup();
    if (!mapNotFound)
        drawPopupInformation("Welcome to Crapple Maps,","Type a city name to get started");
    else
        drawPopupInformation("City map not found.","Type a city name to get started");
    flushinput();
}

/* Function which handles pressing of keyboard keys
 * Detects when arrow keys are pressed and pans up,down,left and right accordingly
 * If enter key is pressed, it loads the feature searched for by the user */
void act_on_keypress (char keyPressed, int keysym){
    if (keysym == LEFT_ARROW_CHAR)
        translate(DIRECTION_LEFT, drawscreen);
    else if (keysym == RIGHT_ARROW_CHAR)
        translate(DIRECTION_RIGHT, drawscreen);
    else if (keysym == UP_ARROW_CHAR)
        translate(DIRECTION_UP, drawscreen);
    else if (keysym == DOWN_ARROW_CHAR)
        translate(DIRECTION_DOWN, drawscreen);
    else if (keysym >= MIN_ALLOWED_ASCII_CHAR && keysym <= MAX_ALLOWED_ASCII_CHAR) {
        searchString = searchString + keyPressed;
        thread partialSearchThread(findPartialSearchResults,searchString);
        partialSearchThread.detach();        
    }
    else if (keysym == BACK_SPACE_CHAR){
        if (searchString.size() > 0) {
            searchString = searchString.erase(searchString.size() - 1);
            thread partialSearchThread(findPartialSearchResults,searchString);
            partialSearchThread.detach();
        }
    }
    else if (keysym == ENTER_CHAR) {
        clearSearchBar();
        loadSearchResults();
    }
    updateSearchMessage(searchString);  // Updates the text in the search bar
    flushinput();
}

// Function to the loads the results based on the text entered in the search bar
void loadSearchResults(){
    
    // Search vectors cleared
    setSearchStatus(false);
    highlightedStreetID.clear();
    highlightedIntersection.clear();
    highlightedIntersectionInfo.clear();
    POIIDS.clear();
    atVectorPos = 0;
    
    // Loads a city map if city name entered, else loads up start screen
    if (searchCities()){
        loadMapData();
        searchString.clear();
        updateSearchMessage(searchString);
        return;
    } 
    else {
        if (currentState == STARTUP){
            mapNotFound = true;
            return;
        }
    }
    
    /* Detect for a comma to check if the user entered the names of two streets
     * in order to search for an intersection*
     * Format of the entered string name can be of three forms:
     * 1. street1,street2  
     * 2. street1, street2 
     * 3. street1 & street2 */
   
    std::size_t pos = searchString.find(',');
    std::size_t pos1 = searchString.find("&");
    
    // Stored all the street ids of the street when a street name is entered
    vector<unsigned> searchStreetIDS = find_street_ids_from_name(searchString); 
     
    std::string street1;
    std::string street2;
    std::vector<unsigned>intersectionIDs;
    
    // If nothing is entered in the search string
    if (searchString.empty())
        return;
    
    // If a comma is found in the search string, displays intersections between the two streets
    else if (pos != std::string::npos || pos1 != std::string::npos){
        // Street name of the form street1,street2
        if (pos !=std::string::npos && pos1 == std::string::npos){
            street1 = searchString.substr(0,pos); //Extracts the first street name
            if (searchString[pos+1] == ' ') // Detects if the format entered in is "street1, street2" 
                pos+=1;
            street2 = searchString.substr(pos+1); // Extracts second street name
            intersectionIDs = find_intersection_ids_from_street_names(street1,street2);
        }
        // Street name of the form street1 & street2
        else if(pos1 != std::string:: npos && pos == std::string::npos){
            street1 = searchString.substr(0,pos1-1); //Extracts the first street name
            street2 = searchString.substr(pos1+2); // Extracts second street name
            intersectionIDs = find_intersection_ids_from_street_names(street1,street2);
        }
        
        // Informs the users if the two streets do not intersect
        if (intersectionIDs.empty()){
            drawPopup();
            drawPopupInformation(searchString, "No matching intersections found");
        }
        
        /* If intersection(s) is/are found, it is highlighted in a circle of a different colour 
         * and the map zooms into the location of the intersection to display it clearly 
         * Pop-up drawn at the bottom of the screen which displays the information of the intersection */       
        else{
            setSearchStatus(true);
            vector<unsigned> searchStreetSegmentIDS;
            for (auto iter = intersectionIDs.begin(); iter != intersectionIDs.end(); iter++) {
                // Extracts all the street segment ids of the intersections and stores it in one vector
                std::vector<unsigned> tempStreetSegments = find_intersection_street_segments(*iter);       
                searchStreetSegmentIDS.insert(searchStreetSegmentIDS.end(), tempStreetSegments.begin(), tempStreetSegments.end());
            }
            // Highlighted intersection vector set, in order to keep these intersections highlighted until dismissed by the user
            highlightedIntersection = intersectionIDs;         

            /* Function call to zoom into the location of the intersections found
             * Bounds of the screen are reset */
            zoomWorldBounds(searchStreetSegmentIDS);  
            
            // Pop-up displayed with the intersection street names, location, and number of intersections found
            pendingIntersection = intersectionIDs[0];
            drawPopup();
            if (intersectionIDs.size() == 1){
                LatLon pos = getIntersectionPosition(intersectionIDs[0]);
                drawPopupInformation(getIntersectionName(intersectionIDs[0]), to_string(pos.lat) + ", " + to_string(pos.lon), POPUP_SELECT);
            } else {
                drawPopupInformation(getIntersectionName(intersectionIDs[0]), "Multiple Intersections found", POPUP_SELECT);
            }
        }
    } 
    
    /* Highlights the street if the user has search for one street  
     * Zooms in to display the entire street 
     * Displays a popup with the name and number of streets found */   
    else if (!searchStreetIDS.empty()) {
        vector<unsigned> searchStreetSegmentIDS;
        setSearchStatus(true);
        
        highlightedStreetID = searchStreetIDS;
        drawNextSearchResult();
        return; //To be removed once the draw screen in the end of this function is removed
    }    
    
    /* Highlights point of interests if the user has searched for a specific POI
     * POI name is compared with what the user inputs in the search bar
     * If there is only one POI location with that name (size is 1), the map zooms into the particular POI*/
    else if (searchString!= "")
    {
        POIIDS.clear();
        POIIDS = drawPoifromname(searchString);
        flushinput();
       if (POIIDS.empty()){
            drawPopup();
            drawPopupInformation(searchString, "No matching results found.");
        }
        else{
            setSearchStatus(true);
            if (POIIDS.size() == 1){
                t_point tp = getAbsoluteXYPos(getPointOfInterestPosition(POIIDS[0]));
                t_bound_box streetBox = t_bound_box(tp.x- BOUNDS_OVERFLOW, tp.y - BOUNDS_OVERFLOW,tp.x + BOUNDS_OVERFLOW, tp.y + BOUNDS_OVERFLOW);
                reset_visible_world(streetBox);
            }
            drawPopup();
            pendingPOIName = getPointOfInterestName(POIIDS[0]);
            drawPopupInformation(searchString, getPointOfInterestType(POIIDS[0]), POPUP_POI_SELECT);
        }
    }
    else {
        drawPopup();
        drawPopupInformation(searchString, "No matching results found");
    }
    drawscreen();
 }

/* Function to reset the bounds of the screen to zoom into a street or intersection searched for by the user 
 * Function goes through each street segment of the required street/intersection and finds the location 
 * of the start and end of the segment. The location of the start and end is converted from lat lon to x and y coordinates 
 * the left,right,top and bottom bounds of the screen are reset to the farthest segment point */
void zoomWorldBounds(std::vector<unsigned> searchStreetSegmentsIDS){
    double left = 50000, right = -50000, top = -50000, bottom = 50000; // Initial screen bounds set to large values
    for (auto itr1 = searchStreetSegmentsIDS.begin(); itr1 != searchStreetSegmentsIDS.end(); itr1++){
        t_point start = getAbsoluteXYPos(getIntersectionPosition(getStreetSegmentInfo(*itr1).from));
        t_point end = getAbsoluteXYPos(getIntersectionPosition(getStreetSegmentInfo(*itr1).to));
        if (start.x > right)
            right = start.x;
        if (start.x < left)
            left = start.x;
        if (end.x > right)
            right = end.x;
        if (end.x < left)
            left = end.x;
        if (start.y > top)
            top = start.y;
        if (start.y < bottom)
            bottom = start.y;
        if (end.y > top)
            top = end.y;
        if (end.y < bottom)
            bottom = end.y;
    }
    t_bound_box streetBox = t_bound_box(left, bottom, right, top);
    reset_visible_world(streetBox); // Draws the map with the new bounds
}

// Function to display the names of the streets and one way streets
void drawStreetNamesAndArrows()
{   // Calls a function to display for each segment of the street
    unsigned streetnum = getNumberOfStreets();
    for (unsigned i=0;i<streetnum;i++)
    {
        std::vector<unsigned> tempSegments=find_street_street_segments(i);
        for (auto iter = tempSegments.begin(); iter!=tempSegments.end();iter++){
            drawStreetSegmentNames(*iter);
            drawStreetSegmentArrows(*iter);
        }           
    }
}

// Displays the name of each segment of the street 
void drawStreetSegmentNames(unsigned i){
    
    StreetSegmentInfo streetseg=getStreetSegmentInfo(i); 
    
    unsigned curvePointCount = streetseg.curvePointCount;
    unsigned start= streetseg.from;
    unsigned end  = streetseg.to;
    string street_name=getStreetName(streetseg.streetID); // Street name extracted
    LatLon position1;
    LatLon position2;
    t_point location;
    t_point location1;
    t_point location2;
    float angle,xLength,yLength;
    
    /* Street names of Ramps and unknown street names are not displaued
     * If the zoom level is less than 9, street names are displayed less frequently
     * It is displayed at each curve point for higher zoom levels*/

    if (street_name.find("Ramp") == string::npos && street_name != "<unknown>"){
        if (currentZoomLevel()<9){
            if (beforeSeg!=street_name){ // Checks if that street name has already been displayed to avoid duplicated segments
                
                /* If there are no curve points in the segment, then name is displayed 
                 * in the center of the segment based on it is starting and ending location */
                if (curvePointCount == 0){
                    position1=getIntersectionPosition(start);
                    position2=getIntersectionPosition(end);
                }
                
                /* If there is one curve point, then name is in the first part of the street
                 * from the start to the curve point */
                else if (curvePointCount == 1){
                    position1=getIntersectionPosition(start);
                    position2=getStreetSegmentCurvePoint(i,0);
                }
                /* For multiple curve points, the name is displayed in the middle of the segment
                 * at the center curve point segment which is middle curvepoint -1 (k-1) to the middle curve point*/
                else if (curvePointCount>=2){
                    unsigned k = (curvePointCount)/2; // Middle curve point
                    position1=getStreetSegmentCurvePoint(i,k-1); 
                    position2=getStreetSegmentCurvePoint(i,k);          
                }
                beforeSeg = street_name;
                
                // Conversion of the location to x and y coordinates
                location1=getAbsoluteXYPos(position1);
                location2=getAbsoluteXYPos(position2);
                
                // Middle of the segment extracted
                location.x = ((location1.x+location2.x)/2);
                location.y= ((location1.y+location2.y)/2);
                xLength = location2.x - location1.x;
                yLength = location2.y - location1.y;
                
                /* Angle for text rotation, to ensure text goes along the street
                 * Based on tan for an right angle triangle; tan(theta) = y/x */             
                angle = atan(yLength/xLength)/DEG_TO_RAD;
                setcolor(BLACK);
                setfontsize(10);
                settextrotation(angle);
                
                // Bounds of the text to not exceed the length of the segment
                drawtext(location,street_name,abs(xLength),abs(yLength));
           }        
        }
        
        /* If the zoom level is greater than 9, the name of the street is displayed 
         * in all of the curve points of the segment by iterating through each point */
        else{
            position1=getIntersectionPosition(start);
            location1=getAbsoluteXYPos(position1);
            
            for(unsigned k=0;k< curvePointCount;k++){
                position2=getStreetSegmentCurvePoint(i,k);
                location2=getAbsoluteXYPos(position2);
                location.x = ((location1.x+location2.x)/2);
                location.y= ((location1.y+location2.y)/2);
                xLength = location2.x - location1.x;
                yLength = location2.y - location1.y;
                angle = atan((yLength)/(xLength))/DEG_TO_RAD;
                setcolor(BLACK);
                setfontsize(12);
                settextrotation(angle);
                drawtext(location,street_name,abs(xLength),abs(yLength));

                location1 = location2;           
            }
            // Displaying the name between the last curve point to the end of the segment
            t_point location2=getAbsoluteXYPos(getIntersectionPosition(end));

            location.x = ((location1.x+location2.x)/2);
            location.y= ((location1.y+location2.y)/2);
            xLength = location2.x - location1.x;
            yLength = location2.y - location1.y;
            angle = atan((yLength)/(xLength))/DEG_TO_RAD;
            setcolor(BLACK);
            setfontsize(12);                
            settextrotation(angle);
            drawtext(location,street_name,abs(xLength), abs(yLength)); 
        }           
    }
}

// Function to indicate one way streets 
void drawStreetSegmentArrows(unsigned i){
    /* Function first checks if the segment is one way, if true it iterates through all the 
     * curve points of the segment and displayed an arrow at the start of the curve point, 
     * rather than the center to avoid coinciding with the street names */
      
    StreetSegmentInfo streetseg=getStreetSegmentInfo(i); 
    
    unsigned curvePointCount = streetseg.curvePointCount;
    unsigned start= streetseg.from;
    unsigned end  = streetseg.to;
    bool oneWayStreet = streetseg.oneWay;

    LatLon position1=getIntersectionPosition(start);
    t_point location1=getAbsoluteXYPos(position1);
    LatLon position2;
    t_point location2;
    t_point location;
    string street_way = "--->";
    float angle,xLength,yLength;

    if (oneWayStreet == true){ 
        for(unsigned k=0;k< curvePointCount;k++)
        {
            position2 = getStreetSegmentCurvePoint(i,k);
            location2 = getAbsoluteXYPos(position2);            
            location.x = location1.x; // Location set to start of the curve point
            location.y = location1.y;
            
            if (currentZoomLevel()>=8) {
                xLength = location2.x - location1.x;
                yLength = location2.y - location1.y;
                angle = atan((yLength)/(xLength))/DEG_TO_RAD;
                setcolor(BLACK);
                setfontsize(10);
                settextrotation(angle);
                drawtext(location,street_way,abs(xLength),abs(yLength));
            }
            
            location1 = location2;
        }
        
        // Displays the arrow between the last curve point and end of the segment
        location2=getAbsoluteXYPos(getIntersectionPosition(end));

        location.x = location1.x;
        location.y= location1.y;
        
        if (currentZoomLevel()>=11 ) {
            xLength = location2.x - location1.x;
            yLength = location2.y - location1.y;
            angle = atan((yLength)/(xLength))/DEG_TO_RAD;
            setcolor(BLACK);
            setfontsize(10);
            settextrotation(angle);
            drawtext(location,street_way,abs(xLength),abs(yLength));
            
        }
    }
}

// Handles mouse clicks 
void act_on_mousebutton (float x, float y, t_event_buttonPressed button_info){
    if (currentState == STARTUP && button_info.button != SEARCH_RESULT_1 && button_info.button != SEARCH_RESULT_2 
            && button_info.button != SEARCH_RESULT_3  && button_info.button != SEARCH_RESULT_4  && button_info.button != SEARCH_RESULT_5)
        return;
    else if (button_info.button == SEARCH_BUTTON) {
        /*If the vectors have something in them, then its a cross. So it removes whatever is shown on
         * screen. If all are empty, then we need to search */
        if (highlightedStreetID.empty() && POIIDS.empty() && highlightedIntersection.empty())
            loadSearchResults();
        else {
            searchString.clear();
            clearAllVectors();
            destroyPopup();
        }    
    } else if (button_info.button == MENU_BUTTON){
        //Opens the menu drawer
        showMenu();
    } else if (button_info.button == NEXT_BUTTON){
        atVectorPos++;
        drawNextSearchResult();
    } else if (button_info.button == SELECT_POI_BUTTON){
        if (intersection1 == INT_MAX && pendingIntersection != INT_MAX) {
            intersection1 = pendingIntersection;
            pendingIntersection = INT_MAX;
        } else if (pendingPOIName != "") {
            POIName = pendingPOIName;
            pendingPOIName = "";
        }
        if (intersection1 != INT_MAX && POIName != ""){
            findPathBetweenIntersectionPOI();
        }
    } else if (button_info.button == SELECT_BUTTON){
        flushinput();
        if (intersection1 == INT_MAX){
            intersection1 = pendingIntersection;
            if (POIName != "")
                findPathBetweenIntersectionPOI();
        } else {
            intersection2 = pendingIntersection;
            findPathBetweenIntersections();
        } 
    } else if (button_info.button == SEARCH_RESULT_1){
        searchString = partialSearchResult[0];
        setSearchStatus(true);
        updateSearchMessage(searchString);
        clearSearchBar();
        loadSearchResults();
    } else if (button_info.button == SEARCH_RESULT_2){
        searchString = partialSearchResult[1];
        setSearchStatus(true);
        updateSearchMessage(searchString);
        clearSearchBar();
        loadSearchResults();
    } else if (button_info.button == SEARCH_RESULT_3){
        searchString = partialSearchResult[2];
        updateSearchMessage(searchString);
        setSearchStatus(true);
        clearSearchBar();
        loadSearchResults();
    } else if (button_info.button == SEARCH_RESULT_4){
        searchString = partialSearchResult[3];
        updateSearchMessage(searchString);
        setSearchStatus(true);
        clearSearchBar();
        loadSearchResults();
    } else if (button_info.button == SEARCH_RESULT_5){
        searchString = partialSearchResult[4];
        setSearchStatus(true);
        updateSearchMessage(searchString);
        clearSearchBar();
        loadSearchResults();
    } else if (button_info.button == HELP_BUTTON){
        showHelpWindow();
    } else
        if (!displayIntersectionInfo(x,y) || !highlightedStreetID.empty() || !POIIDS.empty() || !highlightedIntersection.empty()){
            //If one of these are not empty and the screen   was clicked, then we need to remove what was on screen.
            clearAllVectors();
            searchString.clear();
            updateSearchMessage(searchString);            
            destroyPopup();
            
                //M4 testcases
    std::vector<DeliveryInfo> deliveries;
    std::vector<unsigned> depots;
    std::vector<unsigned> result_path;

//    deliveries = {DeliveryInfo(105225, 56051), DeliveryInfo(104672, 66348), DeliveryInfo(98141, 84950), DeliveryInfo(97060, 67133), DeliveryInfo(88129, 84132), DeliveryInfo(64436, 20885), DeliveryInfo(28619, 64489), DeliveryInfo(79055, 10192), DeliveryInfo(56060, 24341), DeliveryInfo(46379, 91978), DeliveryInfo(80938, 59249), DeliveryInfo(105371, 65267), DeliveryInfo(97919, 93400), DeliveryInfo(61004, 32007), DeliveryInfo(71085, 9140), DeliveryInfo(43327, 19741), DeliveryInfo(63381, 43046), DeliveryInfo(65463, 45138), DeliveryInfo(20649, 47055), DeliveryInfo(32342, 85976), DeliveryInfo(17930, 33578), DeliveryInfo(55705, 98719), DeliveryInfo(108325, 101919), DeliveryInfo(95430, 53600), DeliveryInfo(9748, 7801)};
//    depots = {2, 9256};
//    result_path = traveling_courier(deliveries, depots);
            
//            drawscreen();
        }
    flushinput();
}

/* Loading animation. To give you some pleasure in those excruciating map load wait times 
 * Draws boxes with Rainbow colors with a delay of 300ms
 * Also useful for measuring relative loading time */
void drawLoadingAnimation(){
    destroyPopup();
    clearscreen();
    while (!isStreetsDoneLoading || !isOSMDoneLoading){
        setcolor(PURPLE);
        fillrect(0,400,100,500);
        flushinput();
        delay(300);
        if (isStreetsDoneLoading && isOSMDoneLoading)
            return;
        setcolor(t_color(0x4B,0x00,0x82));
        fillrect(150,400,250,500);
        flushinput();
        delay(300);
        if (isStreetsDoneLoading && isOSMDoneLoading)
            return;
        setcolor(BLUE);
        fillrect(300,400,400,500);
        flushinput();
        delay(300);
        if (isStreetsDoneLoading && isOSMDoneLoading)
            return;
        setcolor(GREEN);
        fillrect(450,400,550,500);
        flushinput();
        delay(300);
        if (isStreetsDoneLoading && isOSMDoneLoading)
            return;
        setcolor(YELLOW);
        fillrect(600,400,700,500);
        flushinput();
        delay(300);
        if (isStreetsDoneLoading && isOSMDoneLoading)
            return;
        setcolor(ORANGE);
        fillrect(750,400,850,500);
        flushinput();
        delay(300);
        if (isStreetsDoneLoading && isOSMDoneLoading)
            return;
        setcolor(RED);
        fillrect(900,400,1000,500);
        flushinput();
        delay(300);
        clearscreen();
    }
}

// If a map name was typed into search and it was to be loaded, this function is called 
void loadMapData(){
    bool redrawMap = false;
    if (streetsBin != "" && osmBin != ""){
        //Clears all vectors and closes the loaded strees bin
        close_map();
        //Clears all vectors and closes the loaded oms bin
        destroyOSMdatabase();
        reset_visible_world(t_bound_box(0,0,1000,1000)); //Resets to these coordinates so that the animation shows up
        redrawMap = true;
    }

    //Multi threaded loading of OSM and streets
    thread osmThread(loadOSMdatabase, osmBin);
    thread mapThread(load_map, streetsBin);

    //Starts loading animation on main thread
    drawLoadingAnimation();
    
    //Waits for both threads to finish
    mapThread.join();
    osmThread.join();
    
    //Sets the current status to LOOP exiting from startup mode.
    currentState = LOOP;
    
    //Sets the world coordinates to show the new map by zooming into the bounds of the map
    LatLon pt1,pt2;
    pt1.lat=smallestLattitude;
    pt1.lon=smallestLongitude;
    pt2.lat=greatestLattitude;
    pt2.lon=greatestLongitude;
    t_point smallest_pt = getAbsoluteXYPos(pt1);
    t_point highest_pt  = getAbsoluteXYPos(pt2);
    t_bound_box new_coords = t_bound_box(smallest_pt.x,smallest_pt.y,highest_pt.x,highest_pt.y);
    reset_visible_world(new_coords);
    currentCoords=get_visible_world();
    
    //Load initial weather data for the center of the map
    thread weatherThread(loadWeather, LatLon((pt1.lat + pt2.lat)/2, (pt1.lon + pt2.lon)/2));
    weatherThread.detach();
    if (redrawMap)
        drawscreen();
    flushinput();
}

// Converts a given LatLon into a xy position to draw on the screen 
t_point getAbsoluteXYPos(LatLon position)
{
    
    /*
     * Implemented as said in the milestone1 document
     * 
     * All degrees to be converted into radians
     * 
     * (x, y) = (lon · cos(latavg), lat) 
     * 
     * d = R ·sqrt( (y2 − y1)^2 + (x2 − x1)^2)
     * 
     *  */
    
    t_point convXY;
    
    float latAvg = (DEG_TO_RAD*greatestLattitude+ DEG_TO_RAD*smallestLattitude)/2;
    
    convXY.x = (DEG_TO_RAD*position.lon * cos(latAvg));
    convXY.y = DEG_TO_RAD*position.lat;
    return convXY;

}

//Iterates through all the features and draws green spaces
void drawGreenery(){
    unsigned featureCount = getNumberOfFeatures();
    
    for (unsigned i = 0; i < featureCount; i++){
        // Check for park(1), greenspace(8), golfcourse(9)
        if (getFeatureType(i)==1||getFeatureType(i)==8||getFeatureType(i)==9){
            setcolor(LIMEGREEN);
            drawPolygon(getFeaturePointCount(i),i);
        }
    }
}
    
//Iterates through all the features and draws water bodies
void drawWaterBodies (){
    unsigned featureCount = getNumberOfFeatures();
    
    for (unsigned i = 0; i < featureCount; i++){
        // check for beach(2), lake(3), river(4), stream(10)
        if (getFeatureType(i)==2||getFeatureType(i)==3||getFeatureType(i)==4 || getFeatureType(i)==10){
            setcolor(LIGHTSKYBLUE);
            drawPolygon(getFeaturePointCount(i),i);
        }
    }
} 

//Iterates through all the features and draws islands
void drawIslands (){
    unsigned featureCount = getNumberOfFeatures();
    
    for (unsigned i = 0; i < featureCount; i++){
        
        // check for island(5), shoreline(6)
        if (getFeatureType(i)==5||getFeatureType(i)==6){
            setcolor(PAPAYAWHIP);
            drawPolygon(getFeaturePointCount(i),i);
        }
        
    }
}
//Iterates through all the features and draws if it is a building or if it is an unknown.
void drawBuildingsAndUnknown(){
    unsigned featureCount = getNumberOfFeatures();
   
    for (unsigned i = 0; i < featureCount; i++){
        
        if(currentZoomLevel()>=6){
            // Check for building(7)
            if (getFeatureType(i)==7){
                setcolor(LIGHTGREY);
                drawPolygon(getFeaturePointCount(i),i);
            }
            // Unknown <- We have no idea what these are
            else if (getFeatureType(i) == 0){
                setcolor(BISQUE);
                drawPolygon(getFeaturePointCount(i),i);
            }    
        }
    }
}

// Does the same as the below function but first gets the coordinates from features points and its ids
void drawPolygon(unsigned featurePoints, unsigned featureId){
    unsigned i =0;
    LatLon start = getFeaturePoint(featureId, i);
    LatLon end = getFeaturePoint(featureId, featurePoints-1);
        
    t_point featurePointsXY[featurePoints];
    featurePointsXY[i] = getAbsoluteXYPos(start);
    bool polygon = false;
    
    if ((start.lat == end.lat) && (start.lon==end.lon)){
        polygon = true;
    }
    
    for (i=1;i<featurePoints; i++){
        LatLon coordinates = getFeaturePoint(featureId, i);
        featurePointsXY[i] = getAbsoluteXYPos(coordinates);
        
        if (polygon == false){
            setlinewidth(3);
            drawline(featurePointsXY[i-1],featurePointsXY[i]);    
        }      
    }
    
    if (polygon==true){
        fillpoly(featurePointsXY, featurePoints);
    }
}

/* 
 * Its something to do with drawing shapes, I guess it draws figures with sides more than 2.
 * It achieves this by iterating through the different points and and forming a closed loop.
 * Then it draws the area of the closed loop.
 * Draws a line in case the feature is not  a closed loop
 */

void drawPolygon(std::vector<LatLon> points){
    bool polygon=false;
    
    //Checks here if it is a polygon or a line
    if ((points[0].lat == points[points.size()-1].lat) && (points[0].lon == points[points.size()-1].lon)){
        polygon = true;
    }
    unsigned i = 0;
    t_point featurePointsXY[points.size()];
    featurePointsXY[i] = getAbsoluteXYPos(points[i]);        

    for (i=1;i<points.size(); i++){
        featurePointsXY[i] = getAbsoluteXYPos(points[i]);

        //Hold your horses, its just a line. Going to draw from one point to another.
        if (polygon == false){
            setlinewidth(5);
            drawline(featurePointsXY[i-1],featurePointsXY[i]);    
        }      
    }
    
    //Draws that multi-sided figure I was talking about earlier
    if (polygon==true){
        fillpoly(featurePointsXY, points.size());
    }
}


/* Draw different types of POI in different layers based on the zoom level
 * All types of POI are drawn on zoom level 6 and above
 * All POI names are drawn on zoom level 10 and above
 * Shows eating places on zoom level 9 to distinguish from other POI types*/
void drawPointofInterest(){ 
    
    currentCoords=get_visible_world();
    for(unsigned i=0;i< getNumberOfPointsOfInterest();i++) {
        LatLon position= getPointOfInterestPosition(i);
        t_point location= getAbsoluteXYPos(position);
        if (location.x>= currentCoords.bottom_left().x && location.y<=currentCoords.top_right().y) {
            if((currentZoomLevel()>=6)) {
            setcolor(RED);
            drawcircle(location);
            }
        }
          
            if(currentZoomLevel()>=12) {
                settextrotation(20);
                setfontsize(10);
                setcolor(BLACK);
                drawtext(location,getPointOfInterestName(i),1000,1000);    
            }
        }         
}

/* Function to display the intersection information for intersection selected by the user
 * x and y parameters are the position pf the coordinates where the user clicked */  
bool displayIntersectionInfo(float x, float y){
    
    // Converts the x,y coordinates to lat lon
    float latAvg = (DEG_TO_RAD * greatestLattitude + DEG_TO_RAD * smallestLattitude)/2;
    
    LatLon convLatLon;
    convLatLon.lat = y/DEG_TO_RAD;
    convLatLon.lon = (x/cos(latAvg))/DEG_TO_RAD;
    
    /* Finds the closest intersection to lat lon position
     * Converts the location of the intersection found to x,y coordinates */
    unsigned intersectionId = find_closest_intersection(convLatLon);
    LatLon intersectionPosition = getIntersectionPosition(intersectionId);
    t_point intersectionXYPos = getAbsoluteXYPos(intersectionPosition);
    
    thread weatherThread(loadWeather, intersectionPosition);
    weatherThread.detach();

    /* Checks if the position where the user clicked is actually at an intersection and not a random location 
     * Small range of 0.000002 is set to locate an intersection*/
    if (intersectionXYPos.x > x-INTERSECTION_OVERFLOW && intersectionXYPos.x < x+INTERSECTION_OVERFLOW){
        if (intersectionXYPos.y > y-INTERSECTION_OVERFLOW && intersectionXYPos.y < y+INTERSECTION_OVERFLOW){
            clearAllVectors();
            
            std::vector<std::string> streets = find_intersection_street_names(intersectionId);
            // Removes repeated street names 
            sort(streets.begin(), streets.end());
            streets.erase(unique(streets.begin(), streets.end()), streets.end());
            
            // Highlights the intersection, and draws popup displayed the information like street names and location of the intersection
            setcolor(MEDIUMPURPLE);
            setlinewidth(5);
            setlinestyle (SOLID);
            std::vector<unsigned>streetSegments = find_intersection_street_segments(intersectionId);
            highlightedIntersectionInfo = streetSegments;            
            drawPopup();
            drawPopupInformation(getIntersectionName(intersectionId), to_string(intersectionPosition.lat) + ", " + to_string(intersectionPosition.lon), POPUP_SELECT);
            if (intersection1 == INT_MAX)
                intersection1 = intersectionId;
            else {
                intersection2 = intersectionId;
                findPathBetweenIntersections();
            }
            drawscreen();
            return true;
        }
    }
    return false;
}

// Draws a circle I 
void drawcircle(t_point location)
{
    fillellipticarc(location.x, location.y,0.0000008,0.0000008,0,360);
}

// Function checks if search input is a city with a map listed. If so, it loads the map. 
bool searchCities(){
    string cityString = searchString;
    
    boost::algorithm::to_lower(cityString); //Converts the search input into lowercase to compare
    
    if (cityString == "toronto"){ 
        streetsBin = TORONTO_STREETS;
        osmBin = TORONTO_OSM;
    } 
    else if (cityString == "newyork" || cityString == "new york"){
        streetsBin = NEWYORK_STREETS;
        osmBin = NEWYORK_OSM;
    }
    else if (cityString == "cairo"){
        streetsBin = CAIRO_STREETS;
        osmBin = CAIRO_OSM;
    }
    else if (cityString == "hamilton"){
        streetsBin = HAMILTON_STREETS;
        osmBin = HAMILTON_OSM;
    }
    else if (cityString == "moscow"){
        streetsBin = MOSCOW_STREETS;
        osmBin = MOSCOW_OSM;
    }
    else if (cityString == "saint helena"){
        streetsBin = SAINT_HELENA_STREETS;
        osmBin = SAINT_HELENA_OSM;
    }
    else if (cityString == "toronto canada" || cityString == "golden horseshoe"){
        streetsBin = TORONTO_CANADA_STREETS;
        osmBin = TORONTO_CANADA_OSM;
    }
    else if (cityString == "london" || cityString == "london england"){
        streetsBin = LONDON_STREETS;
        osmBin = LONDON_OSM;
    }
    else {
        return false;
    }
    return true;
}

// Highlights the POI when searched for. 
std::vector<unsigned> drawPoifromname(string poiname){
    POIIDS= getPointOfInterestID(poiname);
    for (auto itr = POIIDS.begin(); itr != POIIDS.end(); itr++){
        LatLon location= getPointOfInterestPosition(*itr);
        drawHighlightedIntersectionAndPOI(location);
    }
    return POIIDS;
}

/* Draws a circle highlighted Point of interest with different radius 
 * for different zoom levels */
void drawHighlightedIntersectionAndPOI(LatLon position)
{
    t_point location= getAbsoluteXYPos(position);
    if (currentZoomLevel() < 1) {
        fillellipticarc(location.x,location.y, 0.00007, 0.00007, 0, 360);
    }
    else if (currentZoomLevel() == 1) {
        fillellipticarc(location.x,location.y, 0.00005, 0.00005, 0, 360);
    }
    else if (currentZoomLevel() == 2) {
        fillellipticarc(location.x,location.y, 0.00004, 0.00004, 0, 360);
    }
    else if (currentZoomLevel() == 3) {

        fillellipticarc(location.x,location.y, 0.00003, 0.00003, 0, 360);
    }
    else if (currentZoomLevel() == 4) {

        fillellipticarc(location.x,location.y, 0.00002, 0.00002, 0, 360);
    }
    else if (currentZoomLevel() == 5) {

        fillellipticarc(location.x,location.y, 0.000009, 0.000009, 0, 360);
    }
    else if (currentZoomLevel() == 6) {

        fillellipticarc(location.x,location.y, 0.000008, 0.000008, 0, 360);
    }
    else if (currentZoomLevel() == 7) {

        fillellipticarc(location.x,location.y, 0.000005, 0.000005, 0, 360);
    }
    else if (currentZoomLevel() == 8) {

        fillellipticarc(location.x,location.y, 0.000003, 0.000003, 0, 360);
    }
    else if (currentZoomLevel() == 9) {

        fillellipticarc(location.x,location.y, 0.000002, 0.000002, 0, 360);
    }
    else if (currentZoomLevel() >= 10) {

        fillellipticarc(location.x,location.y, 0.0000009, 0.0000009, 0, 360);
    }
    flushinput();
}

/* Draws the osm buildings like airport terminals and train stations. 
 * Draws a polygon around a vector of latlons. */
void drawOSMBuildings(){
    setcolor(LIGHTSTEELBLUE);
    for (auto itr = OSMBuildings.begin(); itr != OSMBuildings.end(); itr++){
        drawPolygon(*itr);
    }
}

// Draws the airport runways. Draws a polygon around a vector of latlons. 
void drawAirportRunway(){
    setcolor(LIGHTSTEELBLUE);
    setlinewidth(2);

    for (auto itr = Runways.begin(); itr != Runways.end(); itr++){
        drawPolygon(*itr);
    } 
}

/* Draws the gas stations. Iterates through the different points of intrerest and draws the 
 * ones with the type fuel.
 * Used when the user clicks on gas stations on the menu. */
void drawGasStations(){
    for(unsigned i=0;i< getNumberOfPointsOfInterest();i++) {
        if(getPointOfInterestType(i)=="fuel"){
            LatLon location= getPointOfInterestPosition(i);
            t_point position= getAbsoluteXYPos(location);
            setcolor(DARKGOLDENROD);
            drawHighlightedIntersectionAndPOI(location);
            setcolor(BLACK);
            if (currentZoomLevel() >= 6){
                setfontsize(10);
                drawtext(position,getPointOfInterestName(i),1000,1000);
            }            
        }
    }
}
/* Draws the cafe. Iterates through the different points of interest and draws the 
 * ones with the type cafe.
 * Used when the user clicks on gas stations on the menu. */
void drawCafes()
{
    for(unsigned i=0;i< getNumberOfPointsOfInterest();i++) {
        if(getPointOfInterestType(i)=="cafe"){
            LatLon location= getPointOfInterestPosition(i);
            t_point position= getAbsoluteXYPos(location);
            setcolor(DARKORCHID);
            drawHighlightedIntersectionAndPOI(location);
            setcolor(BLACK);
            if (currentZoomLevel() >= 11){
                setfontsize(10);
                drawtext(position,getPointOfInterestName(i),1000,1000);
            }            
        }
    }
}
/* Draws the gas hospitals. Iterates through the different points of interest and draws the 
 * ones with the type clinic or hospital or doctor.
 * Used when the user clicks on gas stations on the menu. */
void drawHospitals()
{
    for(unsigned i=0;i< getNumberOfPointsOfInterest();i++) {
        if(getPointOfInterestType(i)=="clinic"||getPointOfInterestType(i)=="doctor"||getPointOfInterestType(i)=="hospital"){
            LatLon location= getPointOfInterestPosition(i);
            t_point position= getAbsoluteXYPos(location);
            setcolor(DARKSLATEBLUE);
            drawHighlightedIntersectionAndPOI(location);
            setcolor(BLACK);
            if (currentZoomLevel() >= 9){
                setfontsize(10);
                drawtext(position,getPointOfInterestName(i),1000,1000);
            }            
        }
    }
}

// Draws the different subway lines in toronto 
void drawTorontoSubways(){
    drawPaths(5, YELLOW, YongeUniversitySpadinaSubway);
    drawPaths(5, GREEN, BloorDanforthSubway);
    drawPaths(5, BLUE, ScarboroughLine);
    drawPaths(5, PURPLE, SheppardLine);
}

/* Function to draw a path that is a vector of latlons. 
 * Iterates through the different points and draws lines between each pair.*/
void drawPaths(double lineWidth, int COLOUR, std::vector<std::vector<LatLon>> vec){
    setlinewidth(lineWidth);
    setcolor(COLOUR);
    for (auto itr = vec.begin(); itr != vec.end(); itr++){
        std::vector<LatLon> pointsVec = *itr;
        for (auto itr1 = pointsVec.begin(); itr1 != (pointsVec.end()-1); itr1++){
            t_point point1 = getAbsoluteXYPos(*itr1);
            t_point point2 = getAbsoluteXYPos(*(itr1 + 1));
            drawline(point1,point2);
        }
    }
}

void drawNextSearchResult(){    
    if (!highlightedStreetID.empty()){
        //Checks if the position at is lesser than the size of the vector (bounds check)
        if (atVectorPos >= highlightedStreetID.size())
            atVectorPos = 0;
        vector<unsigned> searchStreetSegmentIDS;       
        searchStreetSegmentIDS = find_street_street_segments(highlightedStreetID[atVectorPos]); //atVecotPos should be 0.
        drawPopup();
        string resNum = "Showing Result: " + to_string(atVectorPos + 1) + " of " + to_string(highlightedStreetID.size());
        drawPopupInformation(searchString, resNum, (highlightedStreetID.size()>1)?POPUP_NEXT:POPUP_DEFAULT);
        zoomWorldBounds(searchStreetSegmentIDS);
    }    
    drawscreen();
}

//Clears all highlighted stuff
void clearAllVectors(){
    setSearchStatus(false);
    highlightedStreetID.clear();
    highlightedIntersection.clear();
    highlightedIntersectionInfo.clear();
    highlightedPath.clear();
    hideDirections();
    POIIDS.clear();
    atVectorPos = 0;
}

//Handles callback from other threads to the display
void handleCallbacks(){
    if (!areThreadsRunning()){
        lockDisplay();
        extendSearchBar(partialSearchResult.size(), partialSearchResult, true);
        unlockDisplay();
    }
}

//The function handles all operations from calculating the path to displaying it
void findPathBetweenIntersections(){
    //Find the highlighted path
    highlightedPath = find_path_between_intersections(intersection1, intersection2);
    if (highlightedPath.empty()) {
        return;
    }
    //Get the travel directions
    std::vector<directionsStruct> dir = travelDirections(highlightedPath);
    //Draw the directions sidebar
    drawDirections(dir, getStreetName(streetSegmentStreetID[highlightedPath.front()]), getStreetName(streetSegmentStreetID[highlightedPath.back()]), compute_path_travel_time(highlightedPath));
    //Reset all the variables 
    intersection1 = intersection2 = INT_MAX;
    pendingIntersection = INT_MAX;
    drawscreen();
}

//The function handles all operations from calculating the path to displaying it 
void findPathBetweenIntersectionPOI(){
    //Find the highlighted path
    highlightedPath = find_path_to_point_of_interest(intersection1, POIName);
    if (highlightedPath.empty()) {
        return;
    }
    //Get the travel directions
    std::vector<directionsStruct> dir = travelDirections(highlightedPath);
    //Draw the directions sidebar
    drawDirections(dir, getStreetName(streetSegmentStreetID[highlightedPath.front()]), getStreetName(streetSegmentStreetID[highlightedPath.back()]), compute_path_travel_time(highlightedPath));
    //Reset all the variables to MAX
    intersection1 = INT_MAX;
    POIName = "";
    pendingIntersection = INT_MAX;
    drawscreen();
}
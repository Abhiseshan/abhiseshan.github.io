//#include "m4.h"
//#include "m3.h"
//#include <list>
//#include <algorithm>
//#include <chrono>
//#include <boost/date_time.hpp>
//#include <boost/date_time/posix_time/posix_time.hpp>
//
//unsigned starting_depo;
//unsigned ending_depo;
//
//std::vector<unsigned> allPoints;
//typedef std::pair<std::vector<unsigned>,double> paths; 
//std::vector<std::vector<paths>> pointPaths;
//std::vector<unsigned> deliveryPoints;
//std::vector<bool> existsVector;
//
//std::vector<pointsInfo> pointInfo;
//std::vector<pointsInfo> bestPointInfo;
//unsigned pathBegin, pathEnd;
//double bestTravelTime = DBL_MAX;
//
////Private functions
//void pathExpansion(unsigned startPoint);
//void anneal();
//std::vector<unsigned> traveling_courier_kk(const std::vector<DeliveryInfo>& deliveries, const std::vector<unsigned>& depots);
//std::vector<unsigned> two_opt(std::vector<unsigned> &full_path);
//double get_distance_of_path(std::vector<unsigned> &full_path);
//void threadedPathExpansion(unsigned start, unsigned end);
//
//std::mutex thread_lock4;
//#define MAXTHREADS 4
//
////Time stuff
//#define TIME_LIMIT 29200
//boost::posix_time::ptime startTime;
//boost::posix_time::ptime currentTime;
//
//inline bool pairCompare (const std::pair<unsigned, double>& i,const std::pair<unsigned, double>& j) { 
//    return (i.second < j.second); 
//}
//
//inline double timeLeft(){
//    currentTime = boost::posix_time::second_clock::local_time();
//    boost::posix_time::time_duration diff = currentTime - startTime;
//    return diff.total_milliseconds();
//}
//
//inline double randDb() {
//    return (double) rand() / (double) RAND_MAX;
//}
//
//inline bool hasBeenPickedUp(unsigned id) {
//    return pointInfo[id].pickedUp;
//}
//
//inline bool hasBeenVisited(unsigned id) {
//    return (pointInfo[id].nextID != INT_MAX);
//}
//
//bool swapPoints(unsigned pt1, unsigned pt2){    
//    unsigned pt1_next = pointInfo[pt1].nextID;
//    unsigned pt2_next = pointInfo[pt2].nextID;
//    unsigned pt1_next_next = pointInfo[pt1_next].nextID;
//    unsigned pt2_next_next = pointInfo[pt2_next].nextID;
//    
//    if (pt1_next == INT_MAX || pt2_next == INT_MAX || pt1_next_next == INT_MAX || pt2_next_next == INT_MAX)
//        return false;
//    
//    pointInfo[pt1].nextID = pt2_next;
//    pointInfo[pt2].nextID = pt1_next;
//    pointInfo[pt2_next].nextID = pt1_next_next;
//    pointInfo[pt1_next].nextID = pt2_next_next;
//
////     std::size_t size = getNumberOfIntersections();
////    
////    std::vector<pointsInfo> swappedPoints;
////    swappedPoints.resize(size);
////    bool hit = false;
////    unsigned other;
////    unsigned current = pathBegin;
////    while (current != INT_MAX) {
////        if (current == pt1 || current == pt2) {
////            hit = true;
////            other = (current == pt1)?pt2:pt1;
////        }
////    }
//    return true;
//}
//
//// Calculate the acceptance probability
//double acceptanceProbability(int energy, int newEnergy, double temperature){
//    // If the new solution is better, accept it
//    if (newEnergy < energy) {
//        return 1.0;
//    }
//    // If the new solution is worse, calculate an acceptance probability
//    return std::exp((energy - newEnergy) / temperature);
//}   
//
////Returns true if the path is valid
//bool isPathValid(double &travelTime){
//    unsigned current = pathBegin;
//    std::list<unsigned> pickedUpPoints;
//    travelTime = 0;
//    unsigned num = 0;
//    while (current != INT_MAX) {
//        //Invalid case
//        if (current == pointInfo[current].nextID){
////            cout<<"Connected to itself"<<std::endl;
//            return false;
//        }
//        
//        //Calculates the travelTime
//        if (pointInfo[current].nextID != INT_MAX)
//            travelTime += pointPaths[current][pointInfo[current].nextID].second;
//        
//        if (pointInfo[current].type == dropOffType){
//            //Checks if the pickUp point is the last entry on the list
//            if (pointInfo[current].otherPoint == pickedUpPoints.back());
//            //Tries to find the point. If not found, the path is not valid.
//            else if (std::find(pickedUpPoints.begin(), pickedUpPoints.end(), pointInfo[current].otherPoint) == pickedUpPoints.end()){
////                cout<<"Going to drop before pickup."<<std::endl;
//                return false;
//            }
//        }
//        //Adds drop off points to the parsedPoints
//        else if (pointInfo[current].type == pickUpType)
//            pickedUpPoints.push_back(current);
//        
//        //Set the current point to the next point
//        current = pointInfo[current].nextID;
//        num++;
//    }
//    
//    if (num < (deliveryPoints.size() + 1)) {
////        cout<<"Not covering all points."<<std::endl;
////        cout<<"Only "<<num<<" points covered."<<std::endl;
//        return false;
//    }
//    return true;
//}
///*/
//std::vector<unsigned> traveling_courier(const std::vector<DeliveryInfo>& deliveries, const std::vector<unsigned>& depots){
//    
//    startTime = boost::posix_time::second_clock::local_time();
//
//    std::vector<unsigned> result;
//    std::size_t size = getNumberOfIntersections();  
//    auto deliveriesItr = deliveries.begin();  
//    
//    std::list<unsigned> remainingPickups;
//    std::list<unsigned> remainingDropOffs;
//    
//    pointPaths.resize(size);
//    pointInfo.resize(size);
//
//    existsVector.resize(size, false);
//    
//    allPoints.insert(allPoints.begin(), depots.begin(), depots.end());
//    for (auto itr = depots.begin(); itr != depots.end(); itr++){
//        pointInfo[*itr] = {(*itr), INT_MAX, INT_MAX, depoType, INT_MAX, false};
//        existsVector[*itr] = true;
//    }
//    
//    for (deliveriesItr = deliveries.begin(); deliveriesItr != deliveries.end(); deliveriesItr++){
//        allPoints.push_back((*deliveriesItr).pickUp);
//        allPoints.push_back((*deliveriesItr).dropOff);
//        deliveryPoints.push_back((*deliveriesItr).pickUp);
//        deliveryPoints.push_back((*deliveriesItr).dropOff);
//        pointInfo[(*deliveriesItr).pickUp] = {(*deliveriesItr).pickUp, INT_MAX, INT_MAX, pickUpType, (*deliveriesItr).dropOff, false};
//        pointInfo[(*deliveriesItr).dropOff] = {(*deliveriesItr).dropOff, INT_MAX, INT_MAX, dropOffType, (*deliveriesItr).pickUp, false};
//        remainingPickups.push_back((*deliveriesItr).pickUp);
//        remainingDropOffs.push_back((*deliveriesItr).dropOff);
//        existsVector[(*deliveriesItr).pickUp] = true;
//        existsVector[(*deliveriesItr).dropOff] = true;
//    }
//
//    boost::posix_time::ptime t1 = boost::posix_time::second_clock::local_time();    
//
////    for (auto allPts = allPoints.begin(); allPts != allPoints.end(); allPts++) {
////        pathExpansion(*allPts);
////    }
//    
//    //Now using 4 threads
//    unsigned deviation = allPoints.size() / 4;
//        
//    std::thread thread1(threadedPathExpansion, 0, deviation);
//    std::thread thread2(threadedPathExpansion, deviation, deviation*2);
//    std::thread thread3(threadedPathExpansion, deviation*2, deviation*3);
//    std::thread thread4(threadedPathExpansion, deviation*3, allPoints.size());
//    
//    thread1.join();
//    thread2.join();
//    thread3.join();
//    thread4.join();
//    
//    boost::posix_time::ptime t2 = boost::posix_time::second_clock::local_time();    
//    boost::posix_time::time_duration diff1 = t2 - t1;
//    std::cout<<"Total Points: "<<allPoints.size()<<std::endl;
//    std::cout<<"Time for all dij: "<<diff1.total_milliseconds()<<std::endl;
//    std::cout<<"Time per dij: "<<(double) diff1.total_milliseconds() / (double) allPoints.size()<<std::endl;
//    
//    double closestDepoDistance = INT_MAX;  
//    unsigned firstDepoID = 0;
//    unsigned firstPickUpID = 0;
//
//    
//    for (auto iter = depots.begin(); iter != depots.end(); iter++){
//        std::vector<unsigned> connPoints = pointPaths[*iter][*iter].first;
//        for (auto itr = connPoints.begin(); itr != connPoints.end(); itr++){
//            if (pointInfo[*itr].type == pickUpType) {
//                if (pointPaths[*iter][*itr].second < closestDepoDistance){
//                    closestDepoDistance = pointPaths[*iter][*itr].second; 
//                    firstDepoID = *iter;
//                    firstPickUpID = *itr;
//                }
//            }
//        }                    
//    }
////    
////    for (deliveriesItr = deliveries.begin(); deliveriesItr != deliveries.end(); deliveriesItr++){
////            std::vector<unsigned> connPoints = pointPaths[(*deliveriesItr).pickUp][(*deliveriesItr).pickUp].first;        
////            //Determines the closest depo to the point
////            for (auto itr = connPoints.begin(); itr != connPoints.end() && pointInfo[(*deliveriesItr).pickUp].closestDepoID == INT_MAX; itr++){
////                if (pointInfo[*itr].type == depoType) {
////                    pointInfo[(*deliveriesItr).pickUp].closestDepoID = *itr;
////                
////                    if (pointPaths[(*deliveriesItr).pickUp][*itr].second < closestDepoDistance){
////                        closestDepoDistance = pointPaths[(*deliveriesItr).pickUp][*itr].second; 
////                        firstDepoID = *itr;
////                        firstPickUpID = (*deliveriesItr).pickUp;
////                    }
////                }
////            }  
////         
////    }
//    
//    //Make the initial path
//    unsigned current = firstPickUpID; 
//    pathBegin = firstPickUpID;
//    remainingPickups.remove(current);
//    pointInfo[pointInfo[current].otherPoint].pickedUp = true;
//
//    bool done;
//    while (!remainingPickups.empty() || !remainingDropOffs.empty()){
//        done = false;
//        //Gets a list of all points in ascending order of travel time between them
//        std::vector<unsigned> connPoints = pointPaths[current][current].first;
//        
////        //Determines the closest depo to the point
////        for (auto itr = connPoints.begin(); itr != connPoints.end() && pointInfo[current].closestDepoID == INT_MAX; itr++){
////            if (pointInfo[*itr].type == depoType) {
////                pointInfo[current].closestDepoID = *itr;
////            }
////        }
//
//        //Finds the next valid dropOff or pickup
//        for (auto itr = connPoints.begin(); itr != connPoints.end() && !done; itr++){
//
//            if (pointInfo[*itr].type == depoType)
//                continue;
//            
//            else if (pointInfo[*itr].type == dropOffType){
//                if (hasBeenVisited(*itr) || !hasBeenPickedUp(*itr))
//                    continue;
//                else {
//                    pointInfo[current].nextID = *itr;
//                    done = true;
//                    remainingDropOffs.remove(*itr);
//                    current = *itr;
//                }
//            }
//            else if (!hasBeenVisited(*itr)){
//                pointInfo[current].nextID = *itr;
//                done = true;
//                remainingPickups.remove(*itr);
//                current = *itr;
//                pointInfo[pointInfo[current].otherPoint].pickedUp = true;
//            }
//        }
//    }
//     
//    std::vector<unsigned> connPoints = pointPaths[current][current].first;    
//    for (auto itr = connPoints.begin(); itr != connPoints.end() && pointInfo[current].closestDepoID == INT_MAX; itr++){
//        if (pointInfo[*itr].type == depoType) {
//            pointInfo[current].closestDepoID = *itr;
////        std::cout<<"depo"<<std::endl;
//        }
//    }
//                        
//    //Setting up depo
//    pointInfo[firstDepoID].nextID = pathBegin;
//    pathBegin = firstDepoID;
//    
//    std::cout<<"Ecurrent end: "<<current<<std::endl;
//    std::cout<<"end depo : "<<pointInfo[current].closestDepoID<<std::endl;
//    pathEnd = pointInfo[current].closestDepoID;
//
//    /*
//     * Last dropOff point is not linked to the depo. This is to avoid circular loops (same start and 
//     * end depo) from going into infinite loops. For anything, take the path between the last point
//     * and path end.
//     * 
//     
//
//    bestPointInfo = pointInfo;
//  
////    current = pathBegin;
//    
////    while (pointInfo[current].nextID != INT_MAX) {
////        std::cout<<"Pt: "<<current<<std::endl;
////        current = bestPointInfo[current].nextID;
////    }
//    
////    current = pathBegin;
//    
//       
////    int cnt = 0;
//////    int longestDistance = 0;
////    while (current != INT_MAX) {
////        cnt++;
////        std::cout<<current<<std::endl;
////        result.push_back(current);
//////        if (pointPaths[current][pointInfo[current].nextID].second > longestDistance)
//////            longestDistance = pointPaths[current][pointInfo[current].nextID].second;
////        
////#ifdef DEBUG_GRAPHICAL
////        setcolor(RED);
////        drawHighlightedIntersectionAndPOI(getIntersectionPosition(current));
////#endif
////        
////        current = pointInfo[current].nextID;
////    }
////    
////    std::cout<<pathEnd<<std::endl;
////    cnt++;
//    
//    std::cout<<"Path Validity: "<<isPathValid(bestTravelTime)<<std::endl;
//    
//    std::cout<<"Initial Travel Time: "<<bestTravelTime<<std::endl;
//        
////    anneal();
//    
//    current = pathBegin;
//
//    while (pointInfo[current].nextID != INT_MAX) {
//        std::cout<<"Pt: "<<current<<std::endl;
//        std::vector<unsigned> temp = pointPaths[current][bestPointInfo[current].nextID].first;
//        result.insert(result.end(), temp.begin(), temp.end());
//        current = bestPointInfo[current].nextID;
//    }
//    std::cout<<"Point "<<current<<std::endl;
//    std::cout<<"Path End: "<<pathEnd<<std::endl;
//    std::vector<unsigned> temp = pointPaths[current][pathEnd].first;
//    result.insert(result.end(), temp.begin(), temp.end());
//    std::cout<<"Pt: "<<current<<std::endl;
//    
//    std::cout<<"Done Time: "<<timeLeft()<<std::endl;
//    return result;
//}
//*/
//void anneal() {
//    double temperature = 10000;
//    double coolingRate = 0.00001;
//    
//    auto bestPath = pointInfo;
//    auto currentPath = pointInfo;
//    double currentTime = DBL_MAX;
//
//    while (temperature > 1 && timeLeft() < TIME_LIMIT) {
//        //Reset the pointInfo to the current accepted path
//        pointInfo = currentPath;
//        double newTime = 0;
//        
//        //Generate random points to swap
//        unsigned rand1 = deliveryPoints[std::rand() % deliveryPoints.size()];
//        unsigned rand2 = deliveryPoints[std::rand() % deliveryPoints.size()];
//                
//        //if any of the points is invalid, then just go and try again
//        if (!swapPoints(rand1, rand2))
//            continue;
//                
//        //If they are swapped, we check if the path is valid and what is the travel time
//        if (isPathValid(newTime)){
//            
//            //If we accept the solution, we save it to the currentPath
//            if (acceptanceProbability(currentTime, newTime, temperature) > randDb()) {
//                currentPath = pointInfo;
//                currentTime = newTime;
//            }
//            
//            //if the current solution is better than the best solution, update the best solution
//            if (currentTime < bestTravelTime) {                
//                bestPointInfo = currentPath;
//                bestTravelTime = currentTime;
//                std::cout<<"Change in best travel time"<<bestTravelTime<<std::endl;
//                std::cout<<"Time for change "<<timeLeft()<<std::endl;
//            }
//        }
//        
//        temperature *= 1-coolingRate;
////        std::cout<<temperature<<std::endl;
//    }
//    
//    std::cout<<"Best Time: "<<bestTravelTime<<std::endl;
//}
//
//void threadedPathExpansion(unsigned start, unsigned end){
//    for (unsigned i = start; i < end; i++){
////        std::cout<<allPoints[i]<<std::endl;
//        pathExpansion(allPoints[i]);
//    }
//}
//
//void pathExpansion(unsigned startPoint) {
//    std::size_t size = getNumberOfIntersections();  
//    intersectionStruct *intersections = new intersectionStruct[size];
//    
//    unsigned parsedPointsSize = allPoints.size() - 1;
//    
//    pointPaths[startPoint].resize(size);
//    unsigned parsedPoints = 0;
//    
//    //Set weights to infinity and visited to false for all elements
//    for (unsigned z=0; z < size; z++){
//        intersections[z].weights = DBL_MAX;
//        intersections[z].visited = false;
//    }
//    
//    //Priority queue to store intersectionID, weight pairs
//    std::priority_queue<std::pair<unsigned,double> ,std::vector<std::pair<unsigned,double>>, prioritize> heap; 
//
//    //Pushing the source with weight 0
//    heap.push(std::make_pair(startPoint, intersections[startPoint].weights = 0));
//        
//    while (heap.size() != 0){
//        pair<unsigned, double> currentNode = heap.top();
//        heap.pop();
//                
//        unsigned currentID = currentNode.first;
//        
//        //Check if current node has already been visited
//        if (intersections[currentID].visited)
//            continue;
//        
//        if (currentID != startPoint && existsVector[currentID]){
//            pointPaths[startPoint][currentID] = std::make_pair(intersections[currentID].path, compute_path_travel_time(intersections[currentID].path));
//            pointPaths[startPoint][startPoint].first.push_back(currentID); 
//            parsedPoints++;
//            if (parsedPoints == parsedPointsSize+1){
//                return;
//            }
//        }
//        
//        intersections[currentID].visited = true; //If not, set it true since we are visiting the node now
//        
////        for (auto pointsItr = allPoints.begin(); pointsItr != allPoints.end(); pointsItr++){
////            if (currentID == *pointsItr && startPoint != *pointsItr) {  
////                pointPaths[startPoint][*pointsItr] = std::make_pair(intersections[currentID].path, compute_path_travel_time(intersections[currentID].path));
////                pointPaths[startPoint][startPoint].first.push_back(currentID);
////            }
////        }
////        
//        //Gives us all the valid adjacent Nodes after checking for one ways
//        std::vector<unsigned> adjNodes = find_adjacent_intersections(currentID);
//        
//        for (auto itr = adjNodes.begin(); itr != adjNodes.end(); itr++){
//            vector<unsigned> streetSegmentsID;
//            
//            //Checking for the street segments between the current intersection and the intersection
//            //we are looking at
//            if (!intersections[*itr].visited){
//                std::vector<unsigned> streetSegments = find_intersection_street_segments(currentID);
//                                
//                for (auto itr2 = streetSegments.begin(); itr2 != streetSegments.end(); itr2++){
//                    StreetSegmentInfo sgi = getStreetSegmentInfo(*itr2);
//                    if (sgi.from == currentID && sgi.to == *itr)
//                        streetSegmentsID.push_back(*itr2);
//                    else if (sgi.to == currentID && sgi.from == *itr && !sgi.oneWay)
//                        streetSegmentsID.push_back(*itr2);
//                }
//
//                for (auto itr3 = streetSegmentsID.begin(); itr3 != streetSegmentsID.end(); itr3++){
//                    unsigned streetSegment = *itr3;
//                    
//                    /*
//                     * Dijkstra's Algorithm Implementation
//                     * double travelTime = compute_path_travel_time(tempPath); 
//                     */
//
//                    double travelTime = intersections[currentID].weights + findStreetSegmentTravelTime(streetSegment);
//
//                    //If street ids are different, a turn is detected
//                    if (!intersections[currentID].path.empty()) {
//                        if (streetSegmentStreetID[intersections[currentID].path.back()] != streetSegmentStreetID[streetSegment]){
//                            travelTime += TURN_TIME;
//                        }
//                    }
//                    
//                    //Id travel time to a node is lesser, it then replaces it in the weights
//                    if (intersections[*itr].weights > travelTime){
//                        intersections[*itr].weights = travelTime;
//                        intersections[*itr].path = intersections[currentID].path;
//                        intersections[*itr].path.push_back(streetSegment);
//                        heap.push(std::make_pair(*itr, travelTime));
//                    }
//                }
//            }
//        }
//    }
//        
////    std::vector<std::pair<unsigned, double>> closestPoints;
////    double travelTime;
////    
////    for (auto pointsItr = allPoints.begin(); pointsItr != allPoints.end(); pointsItr++){
////        if (startPoint == *pointsItr)
////            continue;
////        travelTime =  compute_path_travel_time(intersections[*pointsItr].path);
////        pointPaths[startPoint][*pointsItr] = std::make_pair(intersections[*pointsItr].path, travelTime);
////        closestPoints.push_back(std::make_pair(*pointsItr, travelTime));
////    }
////    
////    sort(closestPoints.begin(), closestPoints.end(), pairCompare);
////    for (auto clstItr = closestPoints.begin(); clstItr != closestPoints.end(); clstItr++){
////        pointPaths[startPoint][startPoint].first.push_back((*clstItr).first);        
////    }
//    
//    delete[] intersections;
//}
//
///*
//
//std::vector<unsigned> traveling_courier_kk(const std::vector<DeliveryInfo>& deliveries, const std::vector<unsigned>& depots){
//   
//    //create a vector consisting of all intersection ids to be visited 
//    //easier to deal with vectors than structures
//    auto deliveriesItr = deliveries.begin();  
//    std::vector<unsigned> partial_path;
//    std::vector<unsigned> list;
//    for (deliveriesItr = deliveries.begin(); deliveriesItr != deliveries.end(); deliveriesItr++){
//        list.push_back((*deliveriesItr).pickUp);
//        list.push_back((*deliveriesItr).dropOff);
//    }
//    //for now assuming starting depo is same as ending depo , will optimize that later
//    starting_depo= depots[0];
//    ending_depo= starting_depo;
//   //do this after having all the path indexes
//   auto itr2=list.begin();
//   std::vector<unsigned> full_path= find_path_between_intersections(depots[starting_depo], *itr2);
//   for (auto itr = list.begin(); itr != list.end(); itr++){
//       partial_path=find_path_between_intersections(*itr,*(itr+1));
//       full_path.insert(full_path.end(),partial_path.begin(),partial_path.end());
//   }
//   
//    partial_path=find_path_between_intersections(list[list.size()-1],depots[ending_depo]);
//    full_path.insert(full_path.end(),partial_path.begin(),partial_path.end());
//
//    //once we have a basic path we can optimize it using 2 opt
//    //create a vector consisting of all points
//    
//    std::vector<unsigned> all_points;
//    all_points.reserve(list.size()+depots.size());
//    all_points.insert(all_points.end(),list.begin(),list.end());
//    all_points.insert(all_points.end(),depots.begin(),depots.end());
//    
//    
//    std::vector<unsigned> result = two_opt(full_path);  
//    return result; 
//}
//
//std::vector<unsigned> two_opt(std::vector<unsigned> &full_path)
//{
//    double cost= get_distance_of_path(full_path);
//    double new_cost;
//    vector<unsigned> path_new= full_path;
//    vector<unsigned> path_final= full_path;
//    int size= full_path.size();
//    for(int i=1;i<size-1;i++)  //loop will go from first pick up point to the last drop off point
//    {
//        unsigned id_temp= full_path[i];  //store the first pick up point intersection id
//        for(int j=1;j<size-1;j++)
//        {
//            path_new[i]=path_new[j];   //swap the first and second intersection id
//            path_new[j]=temp;
//            
//            new_cost= get_distance_of_path(path_new);
//            if(new_cost<cost)
//            {
//                cost=new_cost;              //change the final path
//                path_final=new_path;
//            }
//            new_path=full_path;                 //if not then dont change anything
//        }
//    }
//    
//    return full_path;
//}
//
//double get_distance_of_path(std::vector<unsigned> &full_path)
//{
//    
//    double sum=0;
//    for(auto itr=full_path.begin();itr!=full_path.end();itr++)
//    {
//        sum+=find_distance_between_two_points((getIntersectionPosition(*itr),getIntersectionPosition(*(itr+1))));
//    }
//    
//    return sum;
//    
//} */
//
///*std::vector<std::vector<double>> distance_between_vectors(std::vector<unsigned> &veca, std::vector<unsigned>&vecb)
//{
//    vector<std::vector<double>> distance_between_vectors;
//    for(auto itr1= veca.begin();itr1!=veca.end();itr++)
//    {
//        for(auto itr2= vecb.begin();itr2!=vecb.end();itr++)
//        {
//            distance_between_vectors(*itr1).push_back(find_distance_between_two_points(getIntersectionPosition(*itr1),getIntersectionPosition(*itr2)));
//        }
//    }
//    return distance_between_vectors;
//}*/

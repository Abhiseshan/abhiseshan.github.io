/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include "newm4.h"

//Path reset vector - Can be cloned to get empty vector of paths
std::vector<pointInfo> pathResetVector;

//Four unique paths for 3 different threads
std::vector<pointInfo> path1;
std::vector<pointInfo> path2;
std::vector<pointInfo> path3;

//Begin and end points for the paths
unsigned path1Begin, path1End, path2Begin, path2End, path3Begin, path3End;

//This vector stores the closest points according to their mean distance (Not actual travel time)
std::vector<std::vector<unsigned>> closestPoints;

//Best measured times for the 3 paths
double bestPath1Time = DBL_MAX;
double bestPath2Time = DBL_MAX;
double bestPath3Time = DBL_MAX;

//Thread kill variables to kill the threads if they are running when the function is about to exit
bool thread1kill = false;
bool thread2kill = false;
bool thread3kill = false;

//Global lists of pickups, depos and dropOffs
std::vector<unsigned> pickUps;
std::vector<unsigned> dropOffs;
std::vector<unsigned> deliveryTypes;
std::vector<unsigned> depos;
std::vector<unsigned> allTypes;

std::vector<unsigned> result;

//Time variables
auto startTime = chrono::high_resolution_clock::now();
#define TIMELIMIT 30000

//private functions
void addPointToPath(unsigned pointID, unsigned otherPoint, int type);
void populateClosestPoints(const unsigned &pointID);
void makeGreedySolution(unsigned startingPoint);

inline double getCurrentMax(){
    if (bestPath1Time == DBL_MAX || bestPath2Time == DBL_MAX || bestPath3Time == DBL_MAX)
        return DBL_MAX;
    
    if (bestPath1Time >= bestPath2Time && bestPath1Time >= bestPath3Time)
        return bestPath1Time;
    else if (bestPath2Time >= bestPath1Time && bestPath2Time >= bestPath3Time)
        return bestPath1Time;
    else
        return bestPath1Time;
}

inline bool hasDeathCome(){
    auto currentTime = chrono::high_resolution_clock::now();
    auto wallClock = chrono::duration_cast<std::chrono::milliseconds> (currentTime - startTime);
 
    return wallClock.count() < TIMELIMIT;
}

unsigned findClosestdepo(unsigned point){
    double least = DBL_MAX;
    unsigned depoID = INT_MAX;
    for (auto itr = depos.begin(); itr != depos.end(); itr++){
        double dist = find_distance_between_two_points(getIntersectionPosition(point), getIntersectionPosition(*itr));
        if (dist < least){
            least = dist;
            depoID = *itr;
        }
    }
    return depoID;
}

double calculateEculidianPathCost(std::vector<unsigned>& path){
    double cost = 0;
    for (auto itr = path.begin(); itr != path.end()-1; itr++){
        cost += find_distance_between_two_points(getIntersectionPosition(*itr), getIntersectionPosition(*(itr+1)));
    }
    return cost;
}

double makeResultVec(std::vector<unsigned>& path){
    result.clear();
    for (auto itr = path.begin(); itr != path.end()-1; itr++){
        std::vector<unsigned> pointPaths = find_path_between_intersections(*itr, *(itr+1));
        result.insert(result.end(), pointPaths.begin(), pointPaths.end());
    }
    
    std::cout<<"Travel Time: "<<compute_path_travel_time(result)<<std::endl;
    return compute_path_travel_time(result);
}

void makeResult(){
    std::vector<unsigned> pathVector;    
    unsigned current = path1Begin;
    while (current != INT_MAX){
        pathVector.push_back(current);
        current = path1[current].nextID; 
    }
    pathVector.push_back(path1End);
    double res1 = makeResultVec(pathVector);
    
    std::vector<unsigned> pathVector2; 
    current = path2Begin;
    while (current != INT_MAX){
        pathVector2.push_back(current);
        current = path2[current].nextID; 
    }
    pathVector2.push_back(path2End);
    double res2 = makeResultVec(pathVector2);

    std::vector<unsigned> pathVector3; 
    current = path3Begin;
    while (current != INT_MAX){
        pathVector3.push_back(current);
        current = path3[current].nextID; 
    }
    pathVector3.push_back(path3End);
    double res3 = makeResultVec(pathVector3);
    
    if (res1 <= res2 && res1 <= res3)
        makeResultVec(pathVector);
    else if (res2 <= res1 && res2 <= res3)
        makeResultVec(pathVector2);
    else
        makeResultVec(pathVector3);
}

std::vector<unsigned> traveling_courier(const std::vector<DeliveryInfo>& deliveries, const std::vector<unsigned>& depots){
    
    /*
     * Basic algorithm implementation
     * The total number of cores avaliable on the CPU's are 4. So we have three threads which are 
     * optimization and one thread for finding the path.
     * 
     * The main thread will keep finding greedy paths by starting from different intersections. When
     * a greedy path is found which is better than one of the current 3 solutions running on the 
     * optimization threads, it kills the worst one and adds the new solution onto the free thread.
     * 
     * The three optimization threads run different algorithms like simulated annealing, 2-opt, etc
     * used for optimization purposes.
     * 
     */
    //get the start time
    startTime = chrono::high_resolution_clock::now();
    
    //Clear all the previous vectors
    pathResetVector.clear();
    pickUps.clear();
    dropOffs.clear();
    depos.clear();
    deliveryTypes.clear();
    allTypes.clear();
    result.clear();
    closestPoints.clear();
    bestPath1Time = DBL_MAX;
    bestPath2Time = DBL_MAX;
    bestPath3Time = DBL_MAX;   
    path1.clear();
    path2.clear();
    path3.clear();
    path1Begin = INT_MAX;
    path1End = INT_MAX;
    path2Begin = INT_MAX;
    path2End = INT_MAX;
    path3Begin = INT_MAX;
    path3End = INT_MAX;    
    thread1kill = false;
    thread2kill = false;
    thread3kill = false;
    
    //Resize the vectors to the desired sizes
    closestPoints.resize(getNumberOfIntersections());
    pathResetVector.resize(getNumberOfIntersections());
    
    //Lets create and populate the basic data structure needed to store all the points
    for (auto depoItr = depots.begin(); depoItr != depots.end(); depoItr++){
        allTypes.push_back(*depoItr);
        addPointToPath(*depoItr, INT_MAX, DEPOTYPE);        
    }
    
    for (auto deliveriesItr = deliveries.begin(); deliveriesItr != deliveries.end(); deliveriesItr++){
        //Add it to all types vector
        allTypes.push_back((*deliveriesItr).pickUp);
        allTypes.push_back((*deliveriesItr).dropOff);
        
        //Adding into the global lists
        pickUps.push_back((*deliveriesItr).pickUp);
        dropOffs.push_back((*deliveriesItr).dropOff);
        
        //Adding into the baseEmptyVector
        addPointToPath((*deliveriesItr).pickUp, (*deliveriesItr).dropOff, PICKUPTYPE);
        addPointToPath((*deliveriesItr).dropOff, (*deliveriesItr).pickUp, DROPOFFTYPE);
    }
    
    deliveryTypes.insert(deliveryTypes.begin(), pickUps.begin(), pickUps.end());
    deliveryTypes.insert(deliveryTypes.end(), dropOffs.begin(), dropOffs.end());
    
    depos = depots;
    
    //Lets get the nearest points in ascending order of distance
    for (auto itr = allTypes.begin(); itr != allTypes.end(); itr++){
        populateClosestPoints(*itr);
    }
    
    unsigned startPoint = 0;
    //Now that all the computation work is done, lets make the greedy solution
    while (hasDeathCome()) {
        makeGreedySolution(pickUps[startPoint]);
        startPoint++;
        if (startPoint == pickUps.size())
            break;
    }   
    
    std::cout<<"death has come"<<std::endl;
    
//    while (hasDeathCome());
    
    thread1kill = true;
    thread2kill = true;
    thread3kill = true;
        
    makeResult();
    return result;
}

void populateClosestPoints(const unsigned &pointID){
    std::vector<std::pair<unsigned, double>> points;
        
    for (auto itr = deliveryTypes.begin(); itr != deliveryTypes.end(); itr++){
        double euclidianDistance = find_distance_between_two_points(getIntersectionPosition(pointID), getIntersectionPosition(*itr));
        points.push_back(std::make_pair(*itr, euclidianDistance));
    }
    
    sort(points.begin(), points.end(), pairCompare);
    
    for (auto itr = points.begin(); itr != points.end(); itr++){
        if ((*itr).first == pointID)
            continue;    
        closestPoints[pointID].push_back((*itr).first);
    }
}

void addPointToPath(unsigned pointID, unsigned otherPoint, int type){
    
    //If it is already a multiPoint
    if (pathResetVector[pointID].multiPoint){
        pathResetVector[pointID].otherPoints.push_back(std::make_pair(otherPoint, type));
    } 
    
    //If it now becomes a multipoint 
    else if (pathResetVector[pointID].pointID != INT_MAX) {
        pathResetVector[pointID].multiPoint = true;
        
        //Adding the current stored information also into otherPoints
        pathResetVector[pointID].otherPoints.push_back(std::make_pair(pathResetVector[pointID].otherPoint, pathResetVector[pointID].type));        
       
        //Adding the new element into the otherPoints
        pathResetVector[pointID].otherPoints.push_back(std::make_pair(otherPoint, type));        
    } 
    
    //Its a new point
    else {
        pathResetVector[pointID].pointID = pointID;
        pathResetVector[pointID].otherPoint = otherPoint;
        pathResetVector[pointID].type = type;
    }
}

void makeGreedySolution(unsigned startingPoint){
    
    //Create the temp list for the new greedy path
    std::vector<pointInfo> tempPath = pathResetVector;

    std::list<unsigned> remainingDropOffs(dropOffs.begin(), dropOffs.end());
    std::list<unsigned> remainingPickUps(pickUps.begin(), pickUps.end());
    
    unsigned currentPoint = startingPoint;
    remainingPickUps.remove(currentPoint);
    
    if (!tempPath[currentPoint].multiPoint){
        tempPath[tempPath[currentPoint].otherPoint].pickedUp = true;
    } else {
        return;
    }
    
    
    while (!remainingDropOffs.empty() || !remainingPickUps.empty()){        
        std::vector<unsigned> nearbyPoints = closestPoints[currentPoint];
             
//        std::cout<<"Current point: "<<currentPoint<<std::endl;
//        std::cout<<"RemainingPickups: "<<remainingPickUps.size()<<std::endl;
//        std::cout<<"remainingDropOffs: "<<remainingDropOffs.size()<<std::endl;
        
//        for (auto itr = remainingDropOffs.begin(); itr != remainingDropOffs.end(); itr++){
//            std::cout<<"remainingDropOffs: "<<*itr<<std::endl;
//        }
        
//        std::cout<<"Point 7169 status: "<<tempPath[7169].pickedUp<<std::endl;
        
        //We want it to stop the upcoming for loop when the correct point is found
        bool found = false;
        
        for (auto itr = nearbyPoints.begin(); itr != nearbyPoints.end() && !found; itr++){
            //Check if the point has been visited
            if (tempPath[*itr].nextID == INT_MAX){                
                //Checks if it is a multiPoint
                if (!tempPath[*itr].multiPoint){
                    if (tempPath[*itr].type == DROPOFFTYPE){
//                        std::cout<<"dropOff "<<*itr<<" "<<tempPath[*itr].pickedUp<<std::endl;
                        if (tempPath[*itr].pickedUp){
                            tempPath[currentPoint].nextID = *itr;
                            found = true;
                            remainingDropOffs.remove(*itr);
                            currentPoint = *itr;
                        }
                    }
                    else {
                        tempPath[currentPoint].nextID = *itr;
                        found = true;
                        remainingPickUps.remove(*itr);
                        currentPoint = *itr;
                        tempPath[tempPath[currentPoint].otherPoint].pickedUp = true;
                    }
                } else {    
                    bool hasDropOff = false;
                    std::vector<unsigned> dropOffPoints;
//                    std::cout<<"ID: "<<*itr<<" size: "<<tempPath[*itr].otherPoints.size();
                    for (auto itr2 = tempPath[*itr].otherPoints.begin(); itr2 != tempPath[*itr].otherPoints.end(); itr2++) {
//                        std::cout << "MultiPath4" << std::endl;
                        if ((*itr2).second == DROPOFFTYPE){
//                        std::cout<<"MultiPath3"<<std::endl;
                            hasDropOff = true;
                            dropOffPoints.push_back((*itr2).first);
                        }
                    }
//                    std::cout<<"MultiPath2"<<std::endl;
                    if (hasDropOff){
                        bool isNotDoneYet = false;
                        for (auto dp = dropOffPoints.begin(); dp != dropOffPoints.end(); dp++){
                            for (auto pk = remainingPickUps.begin(); pk != remainingPickUps.end(); pk++){
                                if (*pk == *dp)
                                    isNotDoneYet = true;
                            }
                        }
                        if (!isNotDoneYet) {
                            tempPath[currentPoint].nextID = *itr;
                            found = true;
                            remainingDropOffs.remove(*itr);
                            for (auto itr2 = tempPath[*itr].otherPoints.begin(); itr2 != tempPath[*itr].otherPoints.end(); itr2++){
                                if ((*itr2).second == PICKUPTYPE){
                                    tempPath[(*itr2).first].pickedUp = true;
                                    remainingPickUps.remove(*itr); //removing from pickups to be sage
                                }
                            }
                            currentPoint = *itr;
                        }
                    } 
                    
                    //If the multi points are only pickups
                    else {
//                        std::cout<<"Only Pickup: "<<*itr<<std::endl;
                        tempPath[currentPoint].nextID = *itr;
                        found = true;
                        remainingPickUps.remove(*itr);
                        currentPoint = *itr;
                        for (auto itr2 = tempPath[*itr].otherPoints.begin(); itr2 != tempPath[*itr].otherPoints.end(); itr2++){
                            tempPath[(*itr2).first].pickedUp = true;
//                            std::cout << (*itr2).first<<std::endl;
//                            std::cout << tempPath[(*itr2).first].pickedUp<<std::endl;
                        }
                    }
                }
            }
        }        
    }
            
    unsigned current = startingPoint;
    
    std::vector<unsigned> pathVector;
    
    unsigned startingDepo = findClosestdepo(current);
    
    tempPath[startingDepo].nextID = startingPoint;
    
    pathVector.push_back(startingDepo);
    
    while (current != INT_MAX){
        pathVector.push_back(current);
        current = tempPath[current].nextID; 
    }
        
    pathVector.push_back(findClosestdepo(pathVector.back()));
    
    double currentPathTime = calculateEculidianPathCost(pathVector);
    
//    std::cout<<"Current Path Time: "<<currentPathTime<<std::endl;
    
    if (currentPathTime < getCurrentMax()){
        if (bestPath1Time == getCurrentMax()){
            thread1kill = true;
            path1 = tempPath;
            path1Begin = pathVector.front();
            path1End = pathVector.back();
            bestPath1Time = currentPathTime;
            //optimize on detached thread
        }
        else if (bestPath2Time == getCurrentMax()){
            thread2kill = true;
            path2 = tempPath;
            path2Begin = pathVector.front();
            path2End = pathVector.back();
            bestPath2Time = currentPathTime;
        }
        else if (bestPath3Time == getCurrentMax()){
            thread3kill = true;
            path3 = tempPath;
            path3Begin = pathVector.front();
            path3End = pathVector.back();
            bestPath3Time = currentPathTime;
        }
    }
}


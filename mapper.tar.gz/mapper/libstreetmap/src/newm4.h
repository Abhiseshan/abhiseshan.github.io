/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   newm4.h
 * Author: abhi
 *
 * Created on March 31, 2016, 8:03 PM
 */

#ifndef NEWM4_H
#define NEWM4_H

#include <iostream>
#include <list>
#include <thread>
#include <chrono>
#include "m1.h"
#include "m3.h"


#define NOTYPE 0
#define PICKUPTYPE 1
#define DROPOFFTYPE 2
#define DEPOTYPE 3

//struct DeliveryInfo {
//    //Specifies a delivery order.
//    //
//    //To satisfy the order the item-to-be-delivered must have been picked-up 
//    //from the pickUp intersection before visiting the dropOff intersection.
//
//    DeliveryInfo(unsigned pick_up, unsigned drop_off)
//        : pickUp(pick_up), dropOff(drop_off) {}
//
//
//    //The intersection id where the item-to-be-delivered is picked-up.
//    unsigned pickUp;
//
//    //The intersection id where the item-to-be-delivered is dropped-off.
//    unsigned dropOff;
//};


struct pointInfo {  
    //Set to true if the point serves as a pickup / dropOff for more than one point
    bool multiPoint;
    
    //Current Point ID
    unsigned pointID;
    
    //The ID of the next point - Set by the path
    unsigned nextID;
    
    //ID to the closest DEPO
    unsigned closestDepoID;
    
    //Other point - Drop off if it is a pickup, 
    unsigned otherPoint; 
    
    //Point type - can be a pickup, dropoff or a depo
    int type;

    //Is set to true if the point has been picked up
    bool pickedUp;
    
    //If it is a multiPoint, this then this stores the other point and whether the current
    //point is a pickup or dropOff to the other point
    std::vector<std::pair<unsigned, int>> otherPoints;
    
    pointInfo(){
        multiPoint = false;
        pointID = INT_MAX;
        nextID = INT_MAX;
        closestDepoID = INT_MAX;
        otherPoint = INT_MAX;
        type = NOTYPE;
        pickedUp = false;
    }
};

std::vector<unsigned> traveling_courier(const std::vector<DeliveryInfo>& deliveries, const std::vector<unsigned>& depots);

inline bool pairCompare (const std::pair<unsigned, double>& i,const std::pair<unsigned, double>& j) { 
    return (i.second < j.second); 
}

double makeResultVec(std::vector<unsigned>& path);

void makeResult();

#endif /* NEWM4_H */